import { useNavigate } from "@tanstack/react-router";
import { useState } from "react";
import { toast } from "sonner";
import {
  ChipMulti,
  ChipSingle,
  Field,
  GroupedChipMulti,
  TextAreaField,
  TextField,
} from "@/components/ls/fields";
import { WizardShell, type WizardStep } from "@/components/ls/wizard";
import {
  ASSIGNMENT_TYPES,
  BILLING_METHODS,
  CLIENT_AVAILABILITY,
  CLIENT_TYPES,
  COMPANY_SIZES,
  DEPLOYMENT_MODELS,
  DURATIONS,
  ENGAGEMENT_TYPES,
  EXPERIENCE_AREAS,
  EXPERIENCE_RANGES,
  HEADCOUNTS,
  INDUSTRIES,
  LOCATIONS,
  MANAGEMENT_LEVELS,
  PRIORITY_FIELDS,
  QUALIFICATIONS,
  REQUIREMENT_TYPES,
  SALARY_BANDS,
  SKILL_GROUPS,
  SOFTWARE_GROUPS,
  TURNOVERS,
  WORK_MODES,
} from "@/lib/ledgerskill/data";
import { newId, saveRequirement } from "@/lib/ledgerskill/store";
import type { ClientRequirement, PriorityField } from "@/lib/ledgerskill/types";
import { cn } from "@/lib/utils";

const defaultPriorities = Object.fromEntries(
  PRIORITY_FIELDS.map((f) => [f, "Preferred"]),
) as Record<PriorityField, "Mandatory" | "Preferred">;

export function ClientForm() {
  const navigate = useNavigate();
  const [index, setIndex] = useState(0);
  const [d, setD] = useState({
    userType: "",
    companyName: "",
    contactPerson: "",
    mobile: "",
    email: "",
    companyLocation: "",
    industry: "",
    companySize: "",
    turnover: "",
    requirementType: "",
    assignmentTitle: "",
    assignmentTypes: [] as string[],
    headcount: "",
    deployment: "",
    managementLevel: "",
    primaryAreas: [] as string[],
    primaryYears: {} as Record<string, string>,
    secondaryAreas: [] as string[],
    secondaryYears: {} as Record<string, string>,
    primarySkills: [] as string[],
    secondarySkills: [] as string[],
    salaryBand: "",
    maxSalary: "",
    billingMethod: "",
    budget: "",
    mandatoryQualifications: [] as string[],
    preferredQualifications: [] as string[],
    mandatorySoftware: [] as string[],
    preferredSoftware: [] as string[],
    primaryIndustry: "",
    preferredIndustries: [] as string[],
    workMode: "",
    locations: [] as string[],
    engagementTypes: [] as string[],
    durations: [] as string[],
    startDate: "",
    weeklyRequirement: "",
    description: "",
    priorities: defaultPriorities,
  });
  type Draft = typeof d;
  const set = <K extends keyof Draft>(k: K, v: Draft[K]) =>
    setD((prev) => ({ ...prev, [k]: v }));

  const steps: WizardStep[] = [
    {
      id: "company",
      title: "Company profile",
      subtitle: "Who is hiring or commissioning the assignment.",
      isValid: Boolean(
        d.userType && d.companyName && d.contactPerson && d.mobile && d.email,
      ),
      render: () => (
        <>
          <ChipSingle
            label="I am registering as"
            required
            options={CLIENT_TYPES}
            value={d.userType}
            onChange={(v) => set("userType", v)}
          />
          <div className="grid gap-6 sm:grid-cols-2">
            <TextField
              label="Company name"
              required
              value={d.companyName}
              onChange={(v) => set("companyName", v)}
            />
            <TextField
              label="Contact person"
              required
              value={d.contactPerson}
              onChange={(v) => set("contactPerson", v)}
            />
            <TextField
              label="Mobile"
              required
              type="tel"
              value={d.mobile}
              onChange={(v) => set("mobile", v)}
            />
            <TextField
              label="Email"
              required
              type="email"
              value={d.email}
              onChange={(v) => set("email", v)}
            />
          </div>
          <ChipSingle
            label="Company location"
            options={LOCATIONS}
            value={d.companyLocation}
            onChange={(v) => set("companyLocation", v)}
          />
          <ChipSingle
            label="Industry"
            options={INDUSTRIES}
            value={d.industry}
            onChange={(v) => set("industry", v)}
          />
          <ChipSingle
            label="Company size"
            options={COMPANY_SIZES}
            value={d.companySize}
            onChange={(v) => set("companySize", v)}
          />
          <ChipSingle
            label="Annual turnover"
            options={TURNOVERS}
            value={d.turnover}
            onChange={(v) => set("turnover", v)}
          />
        </>
      ),
    },
    {
      id: "requirement-type",
      title: "What kind of requirement is this?",
      subtitle:
        "Permanent hire, a defined project or assignment, or manpower you need supplied to your own clients.",
      isValid: Boolean(d.requirementType),
      render: () => (
        <>
          <ChipSingle
            label="Requirement type"
            required
            options={[...REQUIREMENT_TYPES]}
            value={d.requirementType}
            onChange={(v) => set("requirementType", v)}
          />
          <ChipMulti
            label="Assignment / scope of work"
            options={ASSIGNMENT_TYPES}
            value={d.assignmentTypes}
            onChange={(v) => set("assignmentTypes", v)}
          />
          <TextField
            label="Assignment title"
            value={d.assignmentTitle}
            onChange={(v) => set("assignmentTitle", v)}
            placeholder="Statutory audit support for a Noida manufacturing client"
          />
          <ChipSingle
            label="Number of professionals required"
            options={HEADCOUNTS}
            value={d.headcount}
            onChange={(v) => set("headcount", v)}
          />
          <ChipSingle
            label="Where will they work from?"
            options={DEPLOYMENT_MODELS}
            value={d.deployment}
            onChange={(v) => set("deployment", v)}
          />
        </>
      ),
    },
    {
      id: "level",
      title: "Required management level",
      subtitle: "What level of finance professional do you need? Weighted 10%.",
      isValid: Boolean(d.managementLevel),
      render: () => (
        <ChipSingle
          label="Required level"
          required
          options={MANAGEMENT_LEVELS}
          value={d.managementLevel}
          onChange={(v) => set("managementLevel", v)}
        />
      ),
    },
    {
      id: "primary-skills",
      title: "Required primary skills",
      subtitle: "The skills the person must be able to perform. Weighted 30%.",
      isValid: d.primarySkills.length > 0,
      render: () => (
        <GroupedChipMulti
          label="Primary skills required"
          required
          max={5}
          groups={SKILL_GROUPS.map((g) => ({ group: g.group, items: g.skills }))}
          value={d.primarySkills}
          onChange={(v) => set("primarySkills", v)}
        />
      ),
    },
    {
      id: "primary-experience",
      title: "Required primary experience",
      subtitle: "Functional areas the person must have delivered in. Weighted 25%.",
      isValid: d.primaryAreas.length > 0,
      render: () => (
        <>
          <ChipMulti
            label="Primary areas of experience required"
            required
            max={5}
            options={EXPERIENCE_AREAS}
            value={d.primaryAreas}
            onChange={(v) => set("primaryAreas", v)}
          />
        </>
      ),
    },
    {
      id: "budget",
      title: "Salary / budget",
      subtitle: "A primary matching field, weighted 10%.",
      isValid: Boolean(d.salaryBand),
      render: () => (
        <>
          <ChipSingle
            label="Salary budget"
            required
            options={SALARY_BANDS}
            value={d.salaryBand}
            onChange={(v) => set("salaryBand", v)}
          />
          <TextField
            label="Maximum salary budget (₹ per annum)"
            type="number"
            value={d.maxSalary}
            onChange={(v) => set("maxSalary", v)}
          />
          <div className="rule-line" />
          <ChipSingle
            label="Project / consulting billing method"
            options={BILLING_METHODS}
            value={d.billingMethod}
            onChange={(v) => set("billingMethod", v)}
          />
          <TextField
            label="Project budget (₹)"
            type="number"
            value={d.budget}
            onChange={(v) => set("budget", v)}
          />
        </>
      ),
    },
    {
      id: "filters",
      title: "Qualification, software & industry",
      subtitle: "Supporting requirements used to refine the shortlist.",
      render: () => (
        <>
          <ChipMulti
            label="Mandatory qualification"
            options={QUALIFICATIONS}
            value={d.mandatoryQualifications}
            onChange={(v) => set("mandatoryQualifications", v)}
          />
          <ChipMulti
            label="Preferred qualification"
            options={QUALIFICATIONS}
            value={d.preferredQualifications}
            onChange={(v) => set("preferredQualifications", v)}
          />
          <div className="rule-line" />
          <GroupedChipMulti
            label="Mandatory software / ERP"
            groups={SOFTWARE_GROUPS}
            value={d.mandatorySoftware}
            onChange={(v) => set("mandatorySoftware", v)}
          />
          <GroupedChipMulti
            label="Preferred software / ERP"
            groups={SOFTWARE_GROUPS}
            value={d.preferredSoftware}
            onChange={(v) => set("preferredSoftware", v)}
          />
          <div className="rule-line" />
          <ChipMulti
            label="Primary industry experience"
            max={3}
            hint="Choose up to 3"
            options={INDUSTRIES}
            value={d.preferredIndustries}
            onChange={(v) => set("preferredIndustries", v)}
          />
        </>
      ),
    },
    {
      id: "arrangement",
      title: "Work arrangement & engagement",
      subtitle: "Where, how and for how long the work runs.",
      render: () => (
        <>
          <ChipSingle
            label="Work mode"
            options={WORK_MODES}
            value={d.workMode}
            onChange={(v) => set("workMode", v)}
          />
          <ChipMulti
            label="Location"
            options={LOCATIONS.slice(0, 6)}
            value={d.locations}
            onChange={(v) => set("locations", v)}
          />
          <ChipMulti
            label="Engagement type required"
            options={ENGAGEMENT_TYPES}
            value={d.engagementTypes}
            onChange={(v) => set("engagementTypes", v)}
          />
          <ChipMulti
            label="Required duration"
            options={DURATIONS}
            value={d.durations}
            onChange={(v) => set("durations", v)}
          />
          <ChipSingle
            label="When is the professional required?"
            options={CLIENT_AVAILABILITY}
            value={d.startDate}
            onChange={(v) => set("startDate", v)}
          />
        </>
      ),
    },
    {
      id: "priority",
      title: "Matching priority & requirement summary",
      subtitle:
        "Mark each factor Mandatory (a mismatch makes a candidate ineligible) or Preferred (a mismatch only reduces the score).",
      render: () => (
        <>
          <Field label="Matching priority">
            <div className="divide-y divide-border overflow-hidden rounded-lg border border-border bg-card">
              {PRIORITY_FIELDS.map((f) => (
                <div
                  key={f}
                  className="flex items-center justify-between gap-3 px-4 py-3"
                >
                  <span className="text-sm font-medium">{f}</span>
                  <div className="flex gap-1.5">
                    {(["Mandatory", "Preferred"] as const).map((p) => (
                      <button
                        type="button"
                        key={p}
                        onClick={() =>
                          set("priorities", { ...d.priorities, [f]: p })
                        }
                        className={cn(
                          "rounded-md border px-2.5 py-1 text-xs transition-colors",
                          d.priorities[f] === p
                            ? p === "Mandatory"
                              ? "border-destructive bg-destructive text-destructive-foreground"
                              : "border-primary bg-primary text-primary-foreground"
                            : "border-border bg-background hover:bg-accent/50",
                        )}
                      >
                        {p}
                      </button>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          </Field>
          <TextAreaField
            label="Briefly describe your requirement"
            maxLength={300}
            value={d.description}
            onChange={(v) => set("description", v)}
            placeholder="Looking for a GST professional with 3–5 years' relevant experience for a four-month assignment with a manufacturing company in Noida."
          />
        </>
      ),
    },
  ];

  function submit() {
    const req: ClientRequirement = {
      id: newId(),
      createdAt: Date.now(),
      userType: d.userType,
      companyName: d.companyName,
      contactPerson: d.contactPerson,
      mobile: d.mobile,
      email: d.email,
      companyLocation: d.companyLocation,
      industry: d.industry,
      companySize: d.companySize,
      turnover: d.turnover,
      requirementType: d.requirementType,
      assignmentTitle: d.assignmentTitle,
      assignmentTypes: d.assignmentTypes,
      headcount: d.headcount,
      deployment: d.deployment,
      managementLevel: d.managementLevel,
      primaryExperience: d.primaryAreas.map((a) => ({
        name: a,
        years: "",
      })),
      secondaryExperience: d.secondaryAreas.map((a) => ({
        name: a,
        years: d.secondaryYears[a] ?? EXPERIENCE_RANGES[0]!,
      })),
      primarySkills: d.primarySkills,
      secondarySkills: d.secondarySkills,
      salaryBand: d.salaryBand,
      maxSalary: d.maxSalary,
      billingMethod: d.billingMethod,
      budget: d.budget,
      mandatoryQualifications: d.mandatoryQualifications,
      preferredQualifications: d.preferredQualifications,
      mandatorySoftware: d.mandatorySoftware,
      preferredSoftware: d.preferredSoftware,
      primaryIndustry: d.preferredIndustries[0] ?? "",
      preferredIndustries: d.preferredIndustries,
      workMode: d.workMode,
      locations: d.locations,
      engagementTypes: d.engagementTypes,
      durations: d.durations,
      startDate: d.startDate,
      weeklyRequirement: d.weeklyRequirement,
      description: d.description,
      priorities: d.priorities,
    };
    saveRequirement(req);
    toast.success("Requirement posted — scoring the talent pool now.");
    void navigate({ to: "/recruiters", search: { tab: "talent", req: req.id } });
  }

  return (
    <div>
      <WizardShell
        eyebrow="Client requirement"
        steps={steps}
        index={index}
        onIndexChange={setIndex}
        onSubmit={submit}
        submitLabel="Find matches"
      />
    </div>
  );
}