import { Link } from "@tanstack/react-router";
import { useEffect, useMemo, useState } from "react";
import { Search } from "lucide-react";
import { ContactReveal } from "@/components/ls/contact-reveal";
import { ChipSingle, TextField } from "@/components/ls/fields";
import { AD_ENGAGEMENTS, getAds, type VacancyAd } from "@/lib/ledgerskill/ads";
import {
  ENGAGEMENT_TYPES,
  INDUSTRIES,
  LOCATIONS,
  MANAGEMENT_LEVELS,
} from "@/lib/ledgerskill/data";
import { getRequirements } from "@/lib/ledgerskill/store";
import type { ClientRequirement } from "@/lib/ledgerskill/types";

type Opportunity = {
  id: string;
  kind: "Requirement" | "Ad";
  title: string;
  company: string;
  location: string;
  engagement: string;
  industry: string;
  level: string;
  description: string;
  email: string;
  mobile: string;
  tags: string[];
  requirementId?: string;
};

function fromAd(ad: VacancyAd): Opportunity {
  return {
    id: `ad-${ad.id}`,
    kind: "Ad",
    title: ad.position,
    company: ad.company,
    location: ad.location,
    engagement: ad.engagement,
    industry: "",
    level: "",
    description: ad.content,
    email: ad.contactEmail,
    mobile: ad.contactMobile,
    tags: [],
  };
}

function fromRequirement(r: ClientRequirement): Opportunity {
  return {
    id: `req-${r.id}`,
    kind: "Requirement",
    title: r.assignmentTitle || r.requirementType || "Open requirement",
    company: r.companyName,
    location: r.companyLocation || r.locations[0] || "",
    engagement: r.engagementTypes[0] || r.requirementType || "",
    industry: r.primaryIndustry,
    level: r.managementLevel,
    description: r.description,
    email: r.email,
    mobile: r.mobile,
    tags: [
      ...r.primarySkills,
      ...r.mandatorySoftware,
      ...r.mandatoryQualifications,
    ].slice(0, 8),
    requirementId: r.id,
  };
}

function haystack(o: Opportunity) {
  return [
    o.title,
    o.company,
    o.location,
    o.engagement,
    o.industry,
    o.level,
    o.description,
    ...o.tags,
  ]
    .filter(Boolean)
    .join(" ")
    .toLowerCase();
}

type Filters = {
  q: string;
  location: string;
  engagement: string;
  industry: string;
  level: string;
};

function score(o: Opportunity, f: Filters) {
  const hay = haystack(o);
  let got = 0;
  let total = 0;

  const words = f.q.trim().toLowerCase().split(/[\s,]+/).filter(Boolean);
  for (const w of words) {
    total += 2;
    if (hay.includes(w)) got += 2;
  }

  const params: [string, string][] = [
    [f.location, o.location],
    [f.engagement, o.engagement],
    [f.industry, o.industry],
    [f.level, o.level],
  ];
  for (const [want, have] of params) {
    if (!want) continue;
    total += 1;
    if (have && have.toLowerCase().includes(want.toLowerCase())) got += 1;
    else if (hay.includes(want.toLowerCase())) got += 0.5;
  }

  if (total === 0) return 100;
  return Math.round((got / total) * 100);
}

export function OpportunitySearchPanel() {
  const [all, setAll] = useState<Opportunity[]>([]);
  const [qInput, setQInput] = useState("");
  const [locationInput, setLocationInput] = useState("");
  const [engagementInput, setEngagementInput] = useState("");
  const [industryInput, setIndustryInput] = useState("");
  const [levelInput, setLevelInput] = useState("");
  const [filters, setFilters] = useState<Filters>({
    q: "",
    location: "",
    engagement: "",
    industry: "",
    level: "",
  });

  useEffect(() => {
    setAll([
      ...getRequirements().map(fromRequirement),
      ...getAds()
        .filter((a) => a.posterType === "Employer")
        .map(fromAd),
    ]);
  }, []);

  const applySearch = () =>
    setFilters({
      q: qInput,
      location: locationInput,
      engagement: engagementInput,
      industry: industryInput,
      level: levelInput,
    });

  const clear = () => {
    setQInput("");
    setLocationInput("");
    setEngagementInput("");
    setIndustryInput("");
    setLevelInput("");
    setFilters({ q: "", location: "", engagement: "", industry: "", level: "" });
  };

  const results = useMemo(() => {
    const active =
      filters.q.trim() ||
      filters.location ||
      filters.engagement ||
      filters.industry ||
      filters.level;
    return all
      .map((o) => ({ o, match: score(o, filters) }))
      .filter((r) => (active ? r.match > 0 : true))
      .sort((a, b) => b.match - a.match);
  }, [all, filters]);

  return (
    <div>
      <h2 className="text-3xl">Search companies, firms & openings</h2>
      <p className="mt-2 max-w-2xl text-sm text-muted-foreground">
        Search employers, CA firms and outsourcing partners by keyword, then narrow
        by city, engagement type, industry and level. Results are ranked by how
        closely they match what you selected. Contact details unlock with credits.
      </p>

      <section className="mt-6 space-y-6 rounded-xl border border-border bg-surface p-6">
        <TextField
          label="Keyword"
          value={qInput}
          onChange={setQInput}
          placeholder="e.g. statutory audit, controller, GST, SAP, Gurugram"
          onKeyDown={(e) => {
            if (e.key === "Enter") applySearch();
          }}
        />
        <ChipSingle
          label="Location"
          options={LOCATIONS}
          value={locationInput}
          onChange={setLocationInput}
        />
        <ChipSingle
          label="Engagement type"
          options={Array.from(new Set([...ENGAGEMENT_TYPES, ...AD_ENGAGEMENTS]))}
          value={engagementInput}
          onChange={setEngagementInput}
        />
        <ChipSingle
          label="Industry"
          options={INDUSTRIES}
          value={industryInput}
          onChange={setIndustryInput}
        />
        <ChipSingle
          label="Management level"
          options={MANAGEMENT_LEVELS}
          value={levelInput}
          onChange={setLevelInput}
        />
        <div className="flex flex-wrap gap-3">
          <button
            type="button"
            onClick={applySearch}
            className="inline-flex items-center gap-2 rounded-md bg-primary px-5 py-2.5 text-sm font-medium text-primary-foreground hover:opacity-90"
          >
            <Search className="size-4" />
            Search
          </button>
          <button
            type="button"
            onClick={clear}
            className="rounded-md border border-border px-4 py-2.5 text-sm font-medium hover:bg-accent/40"
          >
            Clear filters
          </button>
        </div>
      </section>

      <p className="mt-8 text-sm text-muted-foreground">
        {results.length} opportunit{results.length === 1 ? "y" : "ies"} found
      </p>

      <div className="mt-4 grid gap-5 lg:grid-cols-2">
        {results.map(({ o, match }) => (
          <article key={o.id} className="flex flex-col rounded-xl border border-border bg-card p-6">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <span className="rounded-full bg-accent/50 px-2.5 py-0.5 text-[11px] font-semibold uppercase tracking-[0.12em]">
                {o.kind === "Requirement" ? "Company requirement" : "Hiring ad"}
              </span>
              <span className="text-[11px] font-semibold uppercase tracking-[0.12em] text-muted-foreground">
                {match}% match
              </span>
            </div>
            <h3 className="mt-3 text-xl">
              {o.requirementId ? (
                <Link
                  to="/requirement/$id"
                  params={{ id: o.requirementId }}
                  className="underline-offset-4 hover:underline"
                >
                  {o.title}
                </Link>
              ) : (
                o.title
              )}
            </h3>
            <p className="mt-1 text-sm text-muted-foreground">
              {[o.company, o.location].filter(Boolean).join(" · ")}
            </p>
            <p className="mt-1 text-xs text-muted-foreground">
              {[o.engagement, o.industry, o.level].filter(Boolean).join(" · ")}
            </p>
            {o.description && (
              <p className="mt-4 flex-1 whitespace-pre-line text-sm">{o.description}</p>
            )}
            {o.tags.length > 0 && (
              <div className="mt-4 flex flex-wrap gap-2">
                {o.tags.map((t) => (
                  <span key={t} className="rounded-full bg-accent/50 px-2.5 py-0.5 text-[11px]">
                    {t}
                  </span>
                ))}
              </div>
            )}
            {(o.email || o.mobile) && (
              <div className="mt-5 flex flex-wrap items-center gap-x-5 gap-y-2 border-t border-border pt-4 text-xs">
                {o.email && (
                  <span className="flex items-center gap-2">
                    <span className="text-muted-foreground">Email</span>
                    <ContactReveal contactId={`${o.id}:email`} value={o.email} kind="email" />
                  </span>
                )}
                {o.mobile && (
                  <span className="flex items-center gap-2">
                    <span className="text-muted-foreground">Mobile</span>
                    <ContactReveal contactId={`${o.id}:mobile`} value={o.mobile} kind="phone" />
                  </span>
                )}
              </div>
            )}
          </article>
        ))}
      </div>

      {results.length === 0 && (
        <p className="mt-4 text-sm text-muted-foreground">
          No companies or openings match these filters. Try a broader keyword or clear a filter.
        </p>
      )}
    </div>
  );
}
