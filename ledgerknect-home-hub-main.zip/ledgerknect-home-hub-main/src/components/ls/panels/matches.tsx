import { Link } from "@tanstack/react-router";
import { useEffect, useMemo, useState } from "react";
import { Avatar } from "@/components/ls/avatar";
import { ContactReveal } from "@/components/ls/contact-reveal";
import { WEIGHT_LABELS, type Weights } from "@/lib/ledgerskill/data";
import { rankCandidates } from "@/lib/ledgerskill/matching";
import { getCandidates, getRequirements, getWeights } from "@/lib/ledgerskill/store";
import type { CandidateProfile, ClientRequirement } from "@/lib/ledgerskill/types";
import { cn } from "@/lib/utils";

function scoreTone(score: number, eligible: boolean) {
  if (!eligible) return "text-destructive";
  if (score >= 90) return "text-success";
  if (score >= 70) return "text-foreground";
  return "text-warning";
}

export function MatchesPanel({ req }: { req?: string | undefined }) {
  const [ready, setReady] = useState(false);
  const [requirements, setRequirements] = useState<ClientRequirement[]>([]);
  const [candidates, setCandidates] = useState<CandidateProfile[]>([]);
  const [weights, setWeights] = useState<Weights | null>(null);
  const [selected, setSelected] = useState<string | undefined>(req);
  const [open, setOpen] = useState<string | null>(null);

  useEffect(() => {
    setRequirements(getRequirements());
    setCandidates(getCandidates());
    setWeights(getWeights());
    setReady(true);
  }, []);

  const requirement = useMemo(
    () => requirements.find((r) => r.id === selected) ?? requirements[0],
    [requirements, selected],
  );

  const results = useMemo(
    () =>
      requirement && weights ? rankCandidates(candidates, requirement, weights) : [],
    [candidates, requirement, weights],
  );

  return (
    <div>
      <div>
        <h2 className="text-3xl">Match results</h2>
        <p className="mt-2 max-w-2xl text-sm text-muted-foreground">
          Every professional in the pool is scored against the selected requirement using
          the weighted LedgerKnect model, after a mandatory-requirement eligibility check.
        </p>

        {!ready ? (
          <p className="mt-10 text-sm text-muted-foreground">Loading the talent pool…</p>
        ) : !requirement ? (
          <div className="mt-10 rounded-xl border border-dashed border-border bg-surface p-10 text-center">
            <h2 className="text-2xl">No requirement posted yet</h2>
            <p className="mx-auto mt-2 max-w-md text-sm text-muted-foreground">
              Post a requirement and LedgerKnect will immediately score every registered
              finance professional against it.
            </p>
            <Link
              to="/recruiters"
              search={{ tab: "post" }}
              className="mt-6 inline-flex rounded-md bg-primary px-5 py-2.5 text-sm font-medium text-primary-foreground hover:opacity-90"
            >
              Post a requirement
            </Link>
          </div>
        ) : (
          <>
            {requirements.length > 1 && (
              <div className="mt-8 flex flex-wrap gap-2">
                {requirements.map((r) => (
                  <button
                    key={r.id}
                    type="button"
                    onClick={() => setSelected(r.id)}
                    className={cn(
                      "rounded-full border px-3.5 py-1.5 text-[13px]",
                      r.id === requirement.id
                        ? "border-primary bg-primary text-primary-foreground"
                        : "border-border bg-card hover:bg-accent/40",
                    )}
                  >
                    {r.companyName || "Untitled"} · {r.managementLevel}
                  </button>
                ))}
              </div>
            )}

            <section className="mt-8 rounded-xl border border-border bg-surface p-6">
              <h2 className="text-xl">
                <Link
                  to="/requirement/$id"
                  params={{ id: requirement.id }}
                  className="underline-offset-4 hover:underline"
                >
                  {requirement.companyName}
                </Link>{" "}
                — {requirement.managementLevel}
              </h2>
              {requirement.description && (
                <p className="mt-2 text-sm text-muted-foreground">
                  {requirement.description}
                </p>
              )}
              <dl className="mt-5 grid gap-4 text-sm sm:grid-cols-2 lg:grid-cols-4">
                <Meta label="Primary skills" value={requirement.primarySkills.join(", ")} />
                <Meta
                  label="Primary experience"
                  value={requirement.primaryExperience
                    .map((e) => `${e.name} (${e.years})`)
                    .join(", ")}
                />
                <Meta label="Budget" value={requirement.salaryBand} />
                <Meta
                  label="Work arrangement"
                  value={[requirement.workMode, requirement.locations.join(", ")]
                    .filter(Boolean)
                    .join(" · ")}
                />
              </dl>
            </section>

            <div className="mt-8 space-y-4">
              {results.map((m) => (
                <article
                  key={m.candidate.id}
                  className="rounded-xl border border-border bg-card p-6"
                >
                  <div className="flex flex-wrap items-start justify-between gap-4">
                    <div className="flex items-start gap-4">
                      <Avatar
                        name={m.candidate.fullName}
                        className="h-12 w-12 shrink-0 text-sm"
                      />
                      <div>
                        <h3 className="text-2xl">
                          <Link
                            to="/profile/$id"
                            params={{ id: m.candidate.id }}
                            className="underline-offset-4 hover:underline"
                          >
                            {m.candidate.fullName}
                          </Link>
                        </h3>
                        <p className="mt-1 text-sm text-muted-foreground">
                          {m.candidate.headline ||
                            `${m.candidate.designation} · ${m.candidate.managementLevel}`}
                        </p>
                        <p className="mt-2 text-xs text-muted-foreground">
                          {m.candidate.location} · {m.candidate.salaryBand} ·{" "}
                          {m.candidate.availability}
                        </p>
                        <div className="mt-3 flex flex-wrap items-center gap-x-5 gap-y-2 text-xs">
                          <span className="flex items-center gap-2">
                            <span className="text-muted-foreground">Email</span>
                            <ContactReveal
                              contactId={`candidate:${m.candidate.id}:email`}
                              value={m.candidate.email}
                              kind="email"
                            />
                          </span>
                          <span className="flex items-center gap-2">
                            <span className="text-muted-foreground">Mobile</span>
                            <ContactReveal
                              contactId={`candidate:${m.candidate.id}:mobile`}
                              value={m.candidate.mobile}
                              kind="phone"
                            />
                          </span>
                        </div>
                      </div>
                    </div>
                    <div className="text-right">
                      <p
                        className={cn(
                          "font-display text-4xl leading-none",
                          scoreTone(m.score, m.eligible),
                        )}
                      >
                        {m.eligible ? `${m.score}%` : "—"}
                      </p>
                      <p className="mt-1 text-xs font-semibold uppercase tracking-[0.14em] text-muted-foreground">
                        {m.category}
                      </p>
                    </div>
                  </div>

                  <p className="mt-4 rounded-lg bg-accent/30 px-4 py-3 text-sm">
                    {m.explanation}
                  </p>

                  <button
                    type="button"
                    onClick={() =>
                      setOpen(open === m.candidate.id ? null : m.candidate.id)
                    }
                    className="mt-4 text-sm font-medium underline underline-offset-4 hover:opacity-70"
                  >
                    {open === m.candidate.id ? "Hide" : "View"} match breakdown
                  </button>

                  {open === m.candidate.id && (
                    <div className="mt-4 space-y-2">
                      {m.breakdown.map((row) => (
                        <div key={row.parameter} className="flex items-center gap-4">
                          <span className="w-52 shrink-0 text-sm">
                            {WEIGHT_LABELS[row.parameter as keyof Weights]}
                          </span>
                          <div className="h-2 flex-1 rounded-full bg-muted">
                            <div
                              className="h-full rounded-full bg-gold"
                              style={{ width: `${row.score}%` }}
                            />
                          </div>
                          <span className="w-24 shrink-0 text-right text-sm tabular-nums text-muted-foreground">
                            {row.score}% · {row.weight}w
                          </span>
                        </div>
                      ))}
                      {m.blockers.length > 0 && (
                        <p className="pt-2 text-sm text-destructive">
                          Eligibility blockers: {m.blockers.join("; ")}
                        </p>
                      )}
                      {m.gaps.length > 0 && (
                        <p className="pt-1 text-sm text-muted-foreground">
                          Gaps: {m.gaps.join("; ")}
                        </p>
                      )}
                    </div>
                  )}
                </article>
              ))}
            </div>
          </>
        )}
      </div>
    </div>
  );
}

function Meta({ label, value }: { label: string; value: string }) {
  return (
    <div>
      <dt className="text-[11px] font-semibold uppercase tracking-[0.14em] text-muted-foreground">
        {label}
      </dt>
      <dd className="mt-1">{value || "—"}</dd>
    </div>
  );
}