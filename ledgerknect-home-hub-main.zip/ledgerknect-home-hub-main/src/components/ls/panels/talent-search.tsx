import { Link } from "@tanstack/react-router";
import { useEffect, useMemo, useState } from "react";
import { Search } from "lucide-react";
import { Avatar } from "@/components/ls/avatar";
import { ContactReveal } from "@/components/ls/contact-reveal";
import { ChipSingle, TextField } from "@/components/ls/fields";
import {
  ENGAGEMENT_TYPES,
  LOCATIONS,
  MANAGEMENT_LEVELS,
  QUALIFICATIONS,
} from "@/lib/ledgerskill/data";
import { getCandidates } from "@/lib/ledgerskill/store";
import type { CandidateProfile } from "@/lib/ledgerskill/types";

function haystack(c: CandidateProfile) {
  return [
    c.fullName,
    c.headline,
    c.summary,
    c.designation,
    c.designationOther,
    c.qualification,
    c.primaryIndustry,
    ...c.primarySkills.map((s) => s.name),
    ...c.secondarySkills.map((s) => s.name),
    ...c.primaryExperience.map((e) => e.name),
    ...c.software,
    ...c.industries,
  ]
    .filter(Boolean)
    .join(" ")
    .toLowerCase();
}

export function TalentSearchPanel() {
  const [all, setAll] = useState<CandidateProfile[]>([]);
  const [qInput, setQInput] = useState("");
  const [locationInput, setLocationInput] = useState("");
  const [levelInput, setLevelInput] = useState("");
  const [qualificationInput, setQualificationInput] = useState("");
  const [engagementInput, setEngagementInput] = useState("");
  const [filters, setFilters] = useState({
    q: "",
    location: "",
    level: "",
    qualification: "",
    engagement: "",
  });

  useEffect(() => setAll(getCandidates()), []);

  const applySearch = () => {
    setFilters({
      q: qInput,
      location: locationInput,
      level: levelInput,
      qualification: qualificationInput,
      engagement: engagementInput,
    });
  };

  const clear = () => {
    setQInput("");
    setLocationInput("");
    setLevelInput("");
    setQualificationInput("");
    setEngagementInput("");
    setFilters({ q: "", location: "", level: "", qualification: "", engagement: "" });
  };

  const results = useMemo(() => {
    const needle = filters.q.trim().toLowerCase();
    return all.filter((c) => {
      if (needle && !haystack(c).includes(needle)) return false;
      if (
        filters.location &&
        c.location !== filters.location &&
        !c.preferredLocations.includes(filters.location)
      )
        return false;
      if (filters.level && c.managementLevel !== filters.level) return false;
      if (filters.qualification && c.qualification !== filters.qualification) return false;
      if (filters.engagement && !c.engagementTypes.includes(filters.engagement)) return false;
      return true;
    });
  }, [all, filters]);

  return (
    <div>
      <div>
        <h2 className="text-3xl">Search finance professionals</h2>
        <p className="mt-2 max-w-2xl text-sm text-muted-foreground">
          Search by name, skill, software or industry, then narrow down by city,
          level, qualification and engagement type. Contact details unlock with credits.
        </p>

        <section className="mt-6 space-y-6 rounded-xl border border-border bg-surface p-6">
          <TextField
            label="Keyword"
            value={qInput}
            onChange={setQInput}
            placeholder="e.g. GST, statutory audit, SAP, CA, MIS"
            onKeyDown={(e) => {
              if (e.key === "Enter") applySearch();
            }}
          />
          <ChipSingle
            label="Location"
            options={LOCATIONS}
            value={locationInput}
            onChange={setLocationInput}
          />
          <ChipSingle
            label="Management level"
            options={MANAGEMENT_LEVELS}
            value={levelInput}
            onChange={setLevelInput}
          />
          <ChipSingle
            label="Qualification"
            options={QUALIFICATIONS}
            value={qualificationInput}
            onChange={setQualificationInput}
          />
          <ChipSingle
            label="Engagement type"
            options={ENGAGEMENT_TYPES}
            value={engagementInput}
            onChange={setEngagementInput}
          />
          <div className="flex flex-wrap gap-3">
            <button
              type="button"
              onClick={applySearch}
              className="inline-flex items-center gap-2 rounded-md bg-primary px-5 py-2.5 text-sm font-medium text-primary-foreground hover:opacity-90"
            >
              <Search className="size-4" />
              Search
            </button>
            <button
              type="button"
              onClick={clear}
              className="rounded-md border border-border px-4 py-2.5 text-sm font-medium hover:bg-accent/40"
            >
              Clear filters
            </button>
          </div>
        </section>

        <p className="mt-8 text-sm text-muted-foreground">
          {results.length} professional{results.length === 1 ? "" : "s"} found
        </p>

        <div className="mt-4 grid gap-5 lg:grid-cols-2">
          {results.map((c) => (
            <article key={c.id} className="rounded-xl border border-border bg-card p-6">
              <div className="flex items-start gap-4">
                <Avatar name={c.fullName} className="h-12 w-12 shrink-0 text-sm" />
                <div className="min-w-0">
                  <Link
                    to="/profile/$id"
                    params={{ id: c.id }}
                    className="text-xl underline-offset-4 hover:underline"
                  >
                    {c.fullName}
                  </Link>
                  <p className="mt-1 text-sm text-muted-foreground">
                    {c.headline || `${c.designation} · ${c.managementLevel}`}
                  </p>
                  <p className="mt-1 text-xs text-muted-foreground">
                    {[c.location, c.workMode, c.totalExperience].filter(Boolean).join(" · ")}
                  </p>
                </div>
              </div>
              {c.primarySkills.length > 0 && (
                <div className="mt-4 flex flex-wrap gap-2">
                  {c.primarySkills.slice(0, 5).map((s) => (
                    <span
                      key={s.name}
                      className="rounded-full bg-accent/50 px-2.5 py-0.5 text-[11px]"
                    >
                      {s.name}
                    </span>
                  ))}
                </div>
              )}
              <div className="mt-5 flex flex-wrap items-center gap-x-5 gap-y-2 border-t border-border pt-4 text-xs">
                <span className="flex items-center gap-2">
                  <span className="text-muted-foreground">Email</span>
                  <ContactReveal
                    contactId={`candidate:${c.id}:email`}
                    value={c.email}
                    kind="email"
                  />
                </span>
                <span className="flex items-center gap-2">
                  <span className="text-muted-foreground">Mobile</span>
                  <ContactReveal
                    contactId={`candidate:${c.id}:mobile`}
                    value={c.mobile}
                    kind="phone"
                  />
                </span>
              </div>
            </article>
          ))}
        </div>

        {results.length === 0 && (
          <p className="mt-4 text-sm text-muted-foreground">
            No professionals match these filters. Try clearing a filter or a broader keyword.
          </p>
        )}
      </div>
    </div>
  );
}