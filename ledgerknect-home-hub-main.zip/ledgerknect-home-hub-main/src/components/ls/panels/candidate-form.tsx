import { useNavigate } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { toast } from "sonner";
import {
  ChipMulti,
  ChipSingle,
  Field,
  GroupedChipMulti,
  TextAreaField,
  TextField,
} from "@/components/ls/fields";
import { WizardShell, type WizardStep } from "@/components/ls/wizard";
import {
  AVAILABILITY,
  BILLING_METHODS,
  CERTIFICATIONS,
  DESIGNATIONS,
  DURATIONS,
  ENGAGEMENT_TYPES,
  EXPERIENCE_AREAS,
  EXPERIENCE_RANGES,
  INDUSTRIES,
  LOCATIONS,
  MANAGEMENT_LEVELS,
  PREFERRED_LOCATIONS,
  PROFESSIONAL_STATUS,
  PROFESSIONAL_TYPES,
  PROFICIENCY,
  QUALIFICATIONS,
  SALARY_BANDS,
  SKILL_GROUPS,
  SOFTWARE_GROUPS,
  TOTAL_EXPERIENCE,
  WORK_MODES,
} from "@/lib/ledgerskill/data";
import { newId, saveCandidate } from "@/lib/ledgerskill/store";
import type { CandidateProfile } from "@/lib/ledgerskill/types";

type Draft = {
  userType: string;
  fullName: string;
  mobile: string;
  email: string;
  location: string;
  preferredLocations: string[];
  workMode: string;
  managementLevel: string;
  designation: string;
  designationOther: string;
  totalExperience: string;
  primaryAreas: string[];
  primaryYears: Record<string, string>;
  secondaryAreas: string[];
  secondaryYears: Record<string, string>;
  primarySkills: string[];
  secondarySkills: string[];
  proficiency: Record<string, string>;
  qualification: string;
  professionalStatus: string;
  certifications: string[];
  software: string[];
  softwareProficiency: string;
  industries: string[];
  primaryIndustry: string;
  engagementTypes: string[];
  durations: string[];
  availability: string;
  weeklyAvailability: string;
  salaryBand: string;
  expectedSalary: string;
  minimumSalary: string;
  billingMethod: string;
  expectedRate: string;
  minimumRate: string;
  resumeName: string;
  headline: string;
  summary: string;
};

const empty: Draft = {
  userType: "",
  fullName: "",
  mobile: "",
  email: "",
  location: "",
  preferredLocations: [],
  workMode: "",
  managementLevel: "",
  designation: "",
  designationOther: "",
  totalExperience: "",
  primaryAreas: [],
  primaryYears: {},
  secondaryAreas: [],
  secondaryYears: {},
  primarySkills: [],
  secondarySkills: [],
  proficiency: {},
  qualification: "",
  professionalStatus: "",
  certifications: [],
  software: [],
  softwareProficiency: "",
  industries: [],
  primaryIndustry: "",
  engagementTypes: [],
  durations: [],
  availability: "",
  weeklyAvailability: "",
  salaryBand: "",
  expectedSalary: "",
  minimumSalary: "",
  billingMethod: "",
  expectedRate: "",
  minimumRate: "",
  resumeName: "",
  headline: "",
  summary: "",
};

export function CandidateForm() {
  const navigate = useNavigate();
  const [d, setD] = useState<Draft>(empty);
  const [index, setIndex] = useState(0);
  const set = <K extends keyof Draft>(k: K, v: Draft[K]) =>
    setD((prev) => ({ ...prev, [k]: v }));

  const designations = DESIGNATIONS[d.managementLevel] ?? [];
  const selectedSkills = useMemo(
    () => d.primarySkills,
    [d.primarySkills],
  );

  const steps: WizardStep[] = [
    {
      id: "profile",
      title: "Your profile",
      subtitle: "Basic details so employers and clients can reach you.",
      isValid: Boolean(d.userType && d.fullName && d.mobile && d.email && d.location),
      render: () => (
        <>
          <ChipSingle
            label="I am registering as"
            required
            options={PROFESSIONAL_TYPES}
            value={d.userType}
            onChange={(v) => set("userType", v)}
          />
          <div className="grid gap-6 sm:grid-cols-2">
            <TextField
              label="Full name"
              required
              value={d.fullName}
              onChange={(v) => set("fullName", v)}
              placeholder="e.g. Ankit Bansal"
            />
            <TextField
              label="Mobile number"
              required
              type="tel"
              value={d.mobile}
              onChange={(v) => set("mobile", v)}
              placeholder="98xxxxxxxx"
            />
          </div>
          <TextField
            label="Email address"
            required
            type="email"
            value={d.email}
            onChange={(v) => set("email", v)}
            placeholder="you@example.com"
          />
          <ChipSingle
            label="Current location"
            required
            options={LOCATIONS}
            value={d.location}
            onChange={(v) => set("location", v)}
          />
          <ChipMulti
            label="Preferred work location"
            options={PREFERRED_LOCATIONS}
            value={d.preferredLocations}
            onChange={(v) => set("preferredLocations", v)}
          />
          <ChipSingle
            label="Preferred work mode"
            options={WORK_MODES}
            value={d.workMode}
            onChange={(v) => set("workMode", v)}
          />
        </>
      ),
    },
    {
      id: "level",
      title: "Management level & designation",
      subtitle:
        "Your level tells us the scope of work you operate at. It carries 10% of the match score.",
      isValid: Boolean(d.managementLevel && d.totalExperience),
      render: () => (
        <>
          <ChipSingle
            label="Current / most recent professional level"
            required
            options={MANAGEMENT_LEVELS}
            value={d.managementLevel}
            onChange={(v) => {
              set("managementLevel", v);
              set("designation", "");
            }}
          />
          {d.managementLevel && (
            <ChipSingle
              label="Current / most recent designation"
              options={designations}
              value={d.designation}
              onChange={(v) => set("designation", v)}
            />
          )}
          {d.designation === "Other" && (
            <TextField
              label="Specify designation"
              value={d.designationOther}
              onChange={(v) => set("designationOther", v)}
            />
          )}
          <ChipSingle
            label="Total professional experience"
            required
            options={TOTAL_EXPERIENCE}
            value={d.totalExperience}
            onChange={(v) => set("totalExperience", v)}
          />
        </>
      ),
    },
    {
      id: "primary-skills",
      title: "Primary skills",
      subtitle: "The work you do best. This is the single highest-weighted field at 30%.",
      isValid: d.primarySkills.length > 0,
      render: () => (
        <>
          <GroupedChipMulti
            label="Select your primary skills"
            required
            max={5}
            groups={SKILL_GROUPS.map((g) => ({ group: g.group, items: g.skills }))}
            value={d.primarySkills}
            onChange={(v) => set("primarySkills", v)}
          />
        </>
      ),
    },
    {
      id: "primary-experience",
      title: "Primary experience",
      subtitle: "Functional areas you have genuinely delivered in — weighted 25%.",
      isValid: d.primaryAreas.length > 0,
      render: () => (
        <>
          <ChipMulti
            label="Primary areas of experience"
            required
            max={5}
            options={EXPERIENCE_AREAS}
            value={d.primaryAreas}
            onChange={(v) => set("primaryAreas", v)}
          />
        </>
      ),
    },
    {
      id: "credentials",
      title: "Qualification, software & industry",
      subtitle:
        "Supporting filters. Clients can mark any of these mandatory for a requirement.",
      render: () => (
        <>
          <ChipSingle
            label="Highest qualification"
            options={QUALIFICATIONS}
            value={d.qualification}
            onChange={(v) => set("qualification", v)}
          />
          <ChipSingle
            label="Professional status"
            options={PROFESSIONAL_STATUS}
            value={d.professionalStatus}
            onChange={(v) => set("professionalStatus", v)}
          />
          <ChipMulti
            label="Additional certifications"
            options={CERTIFICATIONS}
            value={d.certifications}
            onChange={(v) => set("certifications", v)}
          />
          <GroupedChipMulti
            label="Software / ERP skills"
            groups={SOFTWARE_GROUPS}
            value={d.software}
            onChange={(v) => set("software", v)}
          />
          <ChipSingle
            label="Overall software proficiency"
            options={PROFICIENCY}
            value={d.softwareProficiency}
            onChange={(v) => set("softwareProficiency", v)}
          />
          <ChipMulti
            label="Primary industry"
            max={3}
            hint="Choose up to 3"
            options={INDUSTRIES}
            value={d.industries}
            onChange={(v) => set("industries", v)}
          />
        </>
      ),
    },
    {
      id: "engagement",
      title: "Engagement & availability",
      subtitle: "How you want to work, and when you can start.",
      render: () => (
        <>
          <ChipMulti
            label="What type of work are you looking for?"
            options={ENGAGEMENT_TYPES}
            value={d.engagementTypes}
            onChange={(v) => set("engagementTypes", v)}
          />
          <ChipMulti
            label="Preferred assignment duration"
            options={DURATIONS}
            value={d.durations}
            onChange={(v) => set("durations", v)}
          />
          <ChipSingle
            label="When can you start?"
            options={AVAILABILITY}
            value={d.availability}
            onChange={(v) => set("availability", v)}
          />
        </>
      ),
    },
    {
      id: "compensation",
      title: "Compensation",
      subtitle: "A primary matching field — it decides whether a role is realistic for you.",
      isValid: Boolean(d.salaryBand),
      render: () => (
        <>
          <ChipSingle
            label="Expected annual salary"
            required
            options={SALARY_BANDS}
            value={d.salaryBand}
            onChange={(v) => set("salaryBand", v)}
          />
          <div className="grid gap-6 sm:grid-cols-2">
            <TextField
              label="Expected salary (₹ per annum)"
              type="number"
              value={d.expectedSalary}
              onChange={(v) => set("expectedSalary", v)}
              placeholder="1500000"
            />
            <TextField
              label="Minimum acceptable salary (₹)"
              type="number"
              value={d.minimumSalary}
              onChange={(v) => set("minimumSalary", v)}
              placeholder="1200000"
            />
          </div>
          <div className="rule-line" />
          <ChipSingle
            label="Consulting / project billing method"
            options={BILLING_METHODS}
            value={d.billingMethod}
            onChange={(v) => set("billingMethod", v)}
          />
          <div className="grid gap-6 sm:grid-cols-2">
            <TextField
              label="Expected rate (₹)"
              type="number"
              value={d.expectedRate}
              onChange={(v) => set("expectedRate", v)}
            />
            <TextField
              label="Minimum acceptable rate (₹)"
              type="number"
              value={d.minimumRate}
              onChange={(v) => set("minimumRate", v)}
            />
          </div>
        </>
      ),
    },
    {
      id: "resume",
      title: "Resume & professional summary",
      subtitle:
        "Upload your CV. In a later release LedgerKnect will read it and pre-fill this profile for your review.",
      render: () => (
        <>
          <Field label="Upload resume / CV" required hint="PDF, DOC or DOCX">
            <label className="flex cursor-pointer flex-col items-center justify-center gap-2 rounded-lg border border-dashed border-border bg-card px-6 py-10 text-center transition-colors hover:border-primary/50">
              <input
                type="file"
                accept=".pdf,.doc,.docx"
                className="hidden"
                onChange={(e) => set("resumeName", e.target.files?.[0]?.name ?? "")}
              />
              <span className="text-sm font-medium">
                {d.resumeName || "Click to select your resume"}
              </span>
              <span className="text-xs text-muted-foreground">
                We will extract designation, skills, experience, industries and software for
                you to confirm.
              </span>
            </label>
          </Field>
          <TextField
            label="Professional headline"
            maxLength={100}
            value={d.headline}
            onChange={(v) => set("headline", v)}
            placeholder="CA | GST & Tax Specialist | 8 Years Experience"
          />
          <TextAreaField
            label="Short professional summary"
            maxLength={300}
            value={d.summary}
            onChange={(v) => set("summary", v)}
            placeholder="CA with 8 years of experience in GST, taxation and financial reporting, with strong manufacturing and MSME exposure."
          />
          <div className="rounded-lg border border-border bg-accent/30 p-4 text-sm">
            <p className="font-semibold">Profile summary</p>
            <p className="mt-1 text-muted-foreground">
              {d.primarySkills.length} primary skills · {d.primaryAreas.length} primary
              experience areas · {selectedSkills.length} skills in total ·{" "}
              {d.managementLevel || "level not set"}
            </p>
          </div>
        </>
      ),
    },
  ];

  function submit() {
    const profile: CandidateProfile = {
      id: newId(),
      createdAt: Date.now(),
      userType: d.userType,
      fullName: d.fullName,
      mobile: d.mobile,
      email: d.email,
      location: d.location,
      preferredLocations: d.preferredLocations,
      workMode: d.workMode,
      managementLevel: d.managementLevel,
      designation: d.designation,
      designationOther: d.designationOther,
      totalExperience: d.totalExperience,
      primaryExperience: d.primaryAreas.map((a) => ({ name: a, years: "" })),
      secondaryExperience: d.secondaryAreas.map((a) => ({
        name: a,
        years: d.secondaryYears[a] ?? EXPERIENCE_RANGES[0]!,
      })),
      primarySkills: d.primarySkills.map((s) => ({
        name: s,
        proficiency: d.proficiency[s] ?? "Advanced",
      })),
      secondarySkills: d.secondarySkills.map((s) => ({
        name: s,
        proficiency: d.proficiency[s] ?? "Intermediate",
      })),
      qualification: d.qualification,
      professionalStatus: d.professionalStatus,
      certifications: d.certifications,
      software: d.software,
      softwareProficiency: d.softwareProficiency,
      industries: d.industries,
      primaryIndustry: d.industries[0] ?? "",
      engagementTypes: d.engagementTypes,
      durations: d.durations,
      availability: d.availability,
      weeklyAvailability: d.weeklyAvailability,
      salaryBand: d.salaryBand,
      expectedSalary: d.expectedSalary,
      minimumSalary: d.minimumSalary,
      billingMethod: d.billingMethod,
      expectedRate: d.expectedRate,
      minimumRate: d.minimumRate,
      resumeName: d.resumeName,
      headline: d.headline,
      summary: d.summary,
    };
    saveCandidate(profile);
    toast.success("Profile submitted — you are now in the LedgerKnect talent pool.");
    void navigate({ to: "/recruiters", search: { tab: "talent" } });
  }

  return (
    <div>
      <WizardShell
        eyebrow="Professional registration"
        steps={steps}
        index={index}
        onIndexChange={setIndex}
        onSubmit={submit}
        submitLabel="Submit profile"
      />
    </div>
  );
}