import { useEffect, useMemo, useState } from "react";
import { Search } from "lucide-react";
import { toast } from "sonner";
import { AdCard } from "@/components/ls/ad-card";
import { ChipSingle, TextAreaField, TextField } from "@/components/ls/fields";
import { AD_ENGAGEMENTS, getAds, saveAd, type VacancyAd } from "@/lib/ledgerskill/ads";
import { LOCATIONS } from "@/lib/ledgerskill/data";
import { newId } from "@/lib/ledgerskill/store";

const empty = {
  posterType: "Employer" as VacancyAd["posterType"],
  position: "",
  company: "",
  location: "Delhi",
  engagement: "Full-Time",
  content: "",
  contactEmail: "",
  contactMobile: "",
};

export function BoardPanel({
  lockPoster,
  allowPost = false,
  heading = "Vacancies & assignments",
  blurb = "Employers, CA firms and outsourcing partners post roles and project work here. Professionals post their availability. Contact details unlock with credits.",
}: {
  lockPoster?: VacancyAd["posterType"];
  allowPost?: boolean;
  heading?: string;
  blurb?: string;
} = {}) {
  const [ads, setAds] = useState<VacancyAd[]>([]);
  const [form, setForm] = useState({ ...empty, ...(lockPoster ? { posterType: lockPoster } : {}) });
  const [posting, setPosting] = useState(false);
  const [qInput, setQInput] = useState("");
  const [fLocationInput, setFLocationInput] = useState("");
  const [fEngagementInput, setFEngagementInput] = useState("");
  const [fPosterInput, setFPosterInput] = useState("");
  const [filters, setFilters] = useState({
    q: "",
    location: "",
    engagement: "",
    poster: "",
  });

  useEffect(() => setAds(getAds()), []);

  const applySearch = () => {
    setFilters({
      q: qInput,
      location: fLocationInput,
      engagement: fEngagementInput,
      poster: fPosterInput,
    });
  };

  const clearFilters = () => {
    setQInput("");
    setFLocationInput("");
    setFEngagementInput("");
    setFPosterInput("");
    setFilters({ q: "", location: "", engagement: "", poster: "" });
  };

  const results = useMemo(() => {
    const needle = filters.q.trim().toLowerCase();
    return ads.filter((ad) => {
      if (lockPoster && ad.posterType !== lockPoster) return false;
      if (
        needle &&
        !`${ad.position} ${ad.company} ${ad.location} ${ad.engagement} ${ad.content}`
          .toLowerCase()
          .includes(needle)
      )
        return false;
      if (filters.location && ad.location !== filters.location) return false;
      if (filters.engagement && ad.engagement !== filters.engagement) return false;
      if (filters.poster && ad.posterType !== filters.poster) return false;
      return true;
    });
  }, [ads, filters, lockPoster]);

  const submit = () => {
    if (!form.position.trim() || !form.company.trim() || !form.content.trim()) {
      toast.error("Position, company and the job profile box are required.");
      return;
    }
    const ad: VacancyAd = { ...form, id: newId(), createdAt: Date.now() };
    saveAd(ad);
    setAds(getAds());
    setForm({ ...empty, ...(lockPoster ? { posterType: lockPoster } : {}) });
    setPosting(false);
    toast.success("Your ad is live on the board.");
  };

  return (
    <div>
      <div>
        <div className="flex flex-wrap items-end justify-between gap-4">
          <div>
            <h2 className="text-3xl">{heading}</h2>
            <p className="mt-2 max-w-2xl text-sm text-muted-foreground">{blurb}</p>
          </div>
          {allowPost && (
            <button
              type="button"
              onClick={() => setPosting((p) => !p)}
              className="rounded-md bg-primary px-5 py-2.5 text-sm font-medium text-primary-foreground hover:opacity-90"
            >
              {posting ? "Close form" : "Post an ad"}
            </button>
          )}
        </div>

        <section className="mt-8 space-y-6 rounded-xl border border-border bg-surface p-6">
          <TextField
            label="Search jobs & assignments"
            value={qInput}
            onChange={setQInput}
            placeholder="e.g. statutory audit, controller, GST, Gurugram"
            onKeyDown={(e) => {
              if (e.key === "Enter") applySearch();
            }}
          />
          {!lockPoster && (
            <ChipSingle
              label="Posted by"
              options={["Employer", "Professional"]}
              value={fPosterInput}
              onChange={setFPosterInput}
            />
          )}
          <ChipSingle
            label="Location"
            options={LOCATIONS}
            value={fLocationInput}
            onChange={setFLocationInput}
          />
          <ChipSingle
            label="Engagement"
            options={AD_ENGAGEMENTS}
            value={fEngagementInput}
            onChange={setFEngagementInput}
          />
          <div className="flex flex-wrap gap-3">
            <button
              type="button"
              onClick={applySearch}
              className="inline-flex items-center gap-2 rounded-md bg-primary px-5 py-2.5 text-sm font-medium text-primary-foreground hover:opacity-90"
            >
              <Search className="size-4" />
              Search
            </button>
            <button
              type="button"
              onClick={clearFilters}
              className="rounded-md border border-border px-4 py-2.5 text-sm font-medium hover:bg-accent/40"
            >
              Clear filters
            </button>
          </div>
        </section>

        {allowPost && posting && (
          <section className="mt-8 space-y-6 rounded-xl border border-border bg-surface p-6">
            {!lockPoster && (
              <ChipSingle
                label="I am posting as"
                options={["Employer", "Professional"]}
                value={form.posterType}
                onChange={(v) =>
                  setForm({ ...form, posterType: v as VacancyAd["posterType"] })
                }
              />
            )}
            <div className="grid gap-5 sm:grid-cols-2">
              <TextField
                label="Position"
                required
                value={form.position}
                onChange={(v) => setForm({ ...form, position: v })}
                placeholder="e.g. Manager — Statutory Audit"
              />
              <TextField
                label="Company / firm"
                required
                value={form.company}
                onChange={(v) => setForm({ ...form, company: v })}
                placeholder="e.g. Verma & Associates"
              />
            </div>
            <ChipSingle
              label="Location"
              options={LOCATIONS}
              value={form.location}
              onChange={(v) => setForm({ ...form, location: v })}
            />
            <ChipSingle
              label="Engagement"
              options={AD_ENGAGEMENTS}
              value={form.engagement}
              onChange={(v) => setForm({ ...form, engagement: v })}
            />
            <TextAreaField
              label="Job profile & conditions"
              value={form.content}
              maxLength={1200}
              onChange={(v) => setForm({ ...form, content: v })}
              placeholder="Scope of work, qualifications, experience, software, duration, budget, reporting, on-site expectations…"
            />
            <div className="grid gap-5 sm:grid-cols-2">
              <TextField
                label="Contact email"
                value={form.contactEmail}
                onChange={(v) => setForm({ ...form, contactEmail: v })}
                placeholder="hiring@company.com"
              />
              <TextField
                label="Contact mobile"
                value={form.contactMobile}
                onChange={(v) => setForm({ ...form, contactMobile: v })}
                placeholder="98xxx xxxxx"
              />
            </div>
            <button
              type="button"
              onClick={submit}
              className="rounded-md bg-primary px-5 py-2.5 text-sm font-medium text-primary-foreground hover:opacity-90"
            >
              Publish ad
            </button>
          </section>
        )}

        <p className="mt-8 text-sm text-muted-foreground">
          {results.length} ad{results.length === 1 ? "" : "s"} found
        </p>

        <div className="mt-4 grid gap-5 lg:grid-cols-2">
          {results.map((ad) => (
            <AdCard key={ad.id} ad={ad} />
          ))}
        </div>
      </div>
    </div>
  );
}
