import { useEffect, useState } from "react";
import { toast } from "sonner";
import {
  CREDITS_EVENT,
  REVEAL_COST,
  isUnlocked,
  maskEmail,
  maskPhone,
  maskText,
  unlockContact,
} from "@/lib/ledgerskill/credits";

type Kind = "email" | "phone" | "text";

function mask(kind: Kind, value: string) {
  if (kind === "email") return maskEmail(value);
  if (kind === "phone") return maskPhone(value);
  return maskText(value);
}

export function ContactReveal({
  contactId,
  value,
  kind = "text",
}: {
  contactId: string;
  value: string;
  kind?: Kind;
}) {
  const [revealed, setRevealed] = useState(false);

  useEffect(() => {
    const sync = () => setRevealed(isUnlocked(contactId));
    sync();
    window.addEventListener(CREDITS_EVENT, sync);
    return () => window.removeEventListener(CREDITS_EVENT, sync);
  }, [contactId]);

  if (!value) return <span>—</span>;
  if (revealed) return <span>{value}</span>;

  return (
    <span className="inline-flex flex-wrap items-center gap-2">
      <span className="tabular-nums text-muted-foreground">{mask(kind, value)}</span>
      <button
        type="button"
        onClick={() => {
          const result = unlockContact(contactId);
          if (result === "insufficient") {
            toast.error("Not enough credits. Buy credits to unlock contact details.");
            return;
          }
          setRevealed(true);
          if (result === "unlocked") {
            toast.success(`Contact unlocked · ${REVEAL_COST} credit used.`);
          }
        }}
        className="rounded-full border border-border px-2.5 py-0.5 text-[11px] font-medium hover:bg-accent/50"
      >
        Unlock ({REVEAL_COST} credit)
      </button>
    </span>
  );
}
