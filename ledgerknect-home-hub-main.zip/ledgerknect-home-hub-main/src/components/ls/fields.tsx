import { Check } from "lucide-react";
import type { ReactNode } from "react";
import { cn } from "@/lib/utils";

export function Field({
  label,
  hint,
  required,
  children,
}: {
  label: string;
  hint?: string | undefined;
  required?: boolean | undefined;
  children: ReactNode;
}) {
  return (
    <div className="space-y-2.5">
      <div className="flex flex-wrap items-baseline gap-x-2">
        <span className="text-sm font-semibold tracking-tight">
          {label}
          {required && <span className="ml-1 text-destructive">*</span>}
        </span>
        {hint && <span className="text-xs text-muted-foreground">{hint}</span>}
      </div>
      {children}
    </div>
  );
}

export function TextField({
  label,
  value,
  onChange,
  placeholder,
  required,
  type = "text",
  maxLength,
  hint,
  onKeyDown,
}: {
  label: string;
  value: string;
  onChange: (v: string) => void;
  placeholder?: string;
  required?: boolean;
  type?: string;
  maxLength?: number;
  hint?: string;
  onKeyDown?: (e: React.KeyboardEvent<HTMLInputElement>) => void;
}) {
  return (
    <Field label={label} required={required} hint={hint}>
      <input
        type={type}
        value={value}
        maxLength={maxLength}
        placeholder={placeholder}
        onChange={(e) => onChange(e.target.value)}
        onKeyDown={onKeyDown}
        className="w-full rounded-md border border-border bg-card px-3 py-2.5 text-sm outline-none transition-colors placeholder:text-muted-foreground/70 focus:border-primary focus:ring-2 focus:ring-ring/15"
      />
    </Field>
  );
}

export function TextAreaField({
  label,
  value,
  onChange,
  placeholder,
  maxLength,
}: {
  label: string;
  value: string;
  onChange: (v: string) => void;
  placeholder?: string;
  maxLength?: number;
}) {
  return (
    <Field
      label={label}
      hint={maxLength ? `${value.length}/${maxLength} characters` : undefined}
    >
      <textarea
        value={value}
        maxLength={maxLength}
        placeholder={placeholder}
        rows={3}
        onChange={(e) => onChange(e.target.value)}
        className="w-full resize-none rounded-md border border-border bg-card px-3 py-2.5 text-sm outline-none transition-colors placeholder:text-muted-foreground/70 focus:border-primary focus:ring-2 focus:ring-ring/15"
      />
    </Field>
  );
}

function chipClass(active: boolean, disabled?: boolean) {
  return cn(
    "inline-flex items-center gap-1.5 rounded-full border px-3.5 py-1.5 text-[13px] transition-all",
    active
      ? "border-primary bg-primary text-primary-foreground shadow-sm"
      : "border-border bg-card text-foreground hover:border-primary/50 hover:bg-accent/40",
    disabled && !active && "cursor-not-allowed opacity-40 hover:border-border hover:bg-card",
  );
}

export function ChipSingle({
  label,
  options,
  value,
  onChange,
  required,
  hint,
}: {
  label: string;
  options: readonly string[];
  value: string;
  onChange: (v: string) => void;
  required?: boolean;
  hint?: string;
}) {
  return (
    <Field label={label} required={required} hint={hint}>
      <div className="flex flex-wrap gap-2">
        {options.map((o) => (
          <button
            type="button"
            key={o}
            onClick={() => onChange(value === o ? "" : o)}
            className={chipClass(value === o)}
          >
            {value === o && <Check className="size-3.5" />}
            {o}
          </button>
        ))}
      </div>
    </Field>
  );
}

export function ChipMulti({
  label,
  options,
  value,
  onChange,
  max,
  required,
  hint,
}: {
  label: string;
  options: readonly string[];
  value: string[];
  onChange: (v: string[]) => void;
  max?: number;
  required?: boolean;
  hint?: string;
}) {
  const full = max !== undefined && value.length >= max;
  return (
    <Field
      label={label}
      required={required}
      hint={max ? `${value.length}/${max} selected${hint ? ` · ${hint}` : ""}` : hint}
    >
      <div className="flex flex-wrap gap-2">
        {options.map((o) => {
          const active = value.includes(o);
          return (
            <button
              type="button"
              key={o}
              disabled={!active && full}
              onClick={() =>
                onChange(active ? value.filter((v) => v !== o) : [...value, o])
              }
              className={chipClass(active, full)}
            >
              {active && <Check className="size-3.5" />}
              {o}
            </button>
          );
        })}
      </div>
    </Field>
  );
}

export function GroupedChipMulti({
  label,
  groups,
  value,
  onChange,
  max,
  required,
}: {
  label: string;
  groups: { group: string; items: string[] }[];
  value: string[];
  onChange: (v: string[]) => void;
  max?: number;
  required?: boolean;
}) {
  const full = max !== undefined && value.length >= max;
  return (
    <Field
      label={label}
      required={required}
      hint={max ? `${value.length}/${max} selected` : undefined}
    >
      <div className="space-y-4">
        {groups.map((g) => (
          <div key={g.group} className="space-y-2">
            <p className="text-[11px] font-semibold uppercase tracking-[0.14em] text-muted-foreground">
              {g.group}
            </p>
            <div className="flex flex-wrap gap-2">
              {g.items.map((o) => {
                const active = value.includes(o);
                return (
                  <button
                    type="button"
                    key={g.group + o}
                    disabled={!active && full}
                    onClick={() =>
                      onChange(active ? value.filter((v) => v !== o) : [...value, o])
                    }
                    className={chipClass(active, full)}
                  >
                    {active && <Check className="size-3.5" />}
                    {o}
                  </button>
                );
              })}
            </div>
          </div>
        ))}
      </div>
    </Field>
  );
}

/** Per-item detail rows: assign a range/proficiency to each selected item. */
export function DetailRows({
  title,
  items,
  options,
  values,
  onChange,
  emptyLabel,
}: {
  title: string;
  items: string[];
  options: readonly string[];
  values: Record<string, string>;
  onChange: (name: string, v: string) => void;
  emptyLabel: string;
}) {
  if (items.length === 0)
    return <p className="text-sm text-muted-foreground">{emptyLabel}</p>;
  return (
    <div className="space-y-3">
      <p className="text-sm font-semibold tracking-tight">{title}</p>
      <div className="divide-y divide-border overflow-hidden rounded-lg border border-border bg-card">
        {items.map((item) => (
          <div
            key={item}
            className="flex flex-wrap items-center justify-between gap-3 px-4 py-3"
          >
            <span className="text-sm font-medium">{item}</span>
            <div className="flex flex-wrap gap-1.5">
              {options.map((o) => (
                <button
                  type="button"
                  key={o}
                  onClick={() => onChange(item, o)}
                  className={cn(
                    "rounded-md border px-2.5 py-1 text-xs transition-colors",
                    values[item] === o
                      ? "border-primary bg-primary text-primary-foreground"
                      : "border-border bg-background hover:bg-accent/50",
                  )}
                >
                  {o}
                </button>
              ))}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}