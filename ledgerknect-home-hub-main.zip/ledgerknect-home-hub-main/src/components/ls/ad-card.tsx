import { ContactReveal } from "@/components/ls/contact-reveal";
import type { VacancyAd } from "@/lib/ledgerskill/ads";

export function AdCard({ ad }: { ad: VacancyAd }) {
  return (
    <article className="flex flex-col rounded-xl border border-border bg-card p-6">
      <div className="flex flex-wrap items-center gap-2">
        <span className="rounded-full bg-accent/50 px-2.5 py-0.5 text-[11px] font-semibold uppercase tracking-[0.12em]">
          {ad.posterType === "Employer" ? "Hiring" : "Available"}
        </span>
        <span className="text-[11px] uppercase tracking-[0.12em] text-muted-foreground">
          {ad.engagement}
        </span>
      </div>
      <h3 className="mt-3 text-xl">{ad.position}</h3>
      <p className="mt-1 text-sm text-muted-foreground">
        {ad.company} · {ad.location}
      </p>
      <p className="mt-4 flex-1 whitespace-pre-line text-sm">{ad.content}</p>
      {(ad.contactEmail || ad.contactMobile) && (
        <div className="mt-5 flex flex-wrap items-center gap-x-5 gap-y-2 border-t border-border pt-4 text-xs">
          {ad.contactEmail && (
            <span className="flex items-center gap-2">
              <span className="text-muted-foreground">Email</span>
              <ContactReveal
                contactId={`ad:${ad.id}:email`}
                value={ad.contactEmail}
                kind="email"
              />
            </span>
          )}
          {ad.contactMobile && (
            <span className="flex items-center gap-2">
              <span className="text-muted-foreground">Mobile</span>
              <ContactReveal
                contactId={`ad:${ad.id}:mobile`}
                value={ad.contactMobile}
                kind="phone"
              />
            </span>
          )}
        </div>
      )}
    </article>
  );
}
