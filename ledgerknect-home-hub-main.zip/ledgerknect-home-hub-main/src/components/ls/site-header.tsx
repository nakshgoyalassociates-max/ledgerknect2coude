import { Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { CREDITS_EVENT, getBalance } from "@/lib/ledgerskill/credits";

const nav = [
  { to: "/recruiters", label: "Recruiters" },
  { to: "/professionals", label: "Professionals" },
  { to: "/about", label: "About" },
  { to: "/contact", label: "Contact" },
  { to: "/admin", label: "Admin" },
  { to: "/register", label: "Register" },
] as const;

export function SiteHeader() {
  const [credits, setCredits] = useState<number | null>(null);

  useEffect(() => {
    const sync = () => setCredits(getBalance());
    sync();
    window.addEventListener(CREDITS_EVENT, sync);
    return () => window.removeEventListener(CREDITS_EVENT, sync);
  }, []);

  return (
    <header className="sticky top-0 z-40 border-b border-border bg-background/85 backdrop-blur">
      <div className="mx-auto flex h-16 w-full max-w-6xl items-center justify-between px-5">
        <Link to="/" className="flex items-baseline gap-2">
          <span className="font-display text-xl tracking-tight">LedgerKnect</span>
          <span className="hidden text-[10px] uppercase tracking-[0.22em] text-muted-foreground sm:inline">
            Delhi NCR
          </span>
        </Link>
        <nav className="flex items-center gap-1">
          {nav.map((n) => (
            <Link
              key={n.to}
              to={n.to}
              activeProps={{ className: "bg-accent/60 text-foreground" }}
              className="rounded-md px-3 py-1.5 text-[13px] text-muted-foreground transition-colors hover:text-foreground"
            >
              {n.label}
            </Link>
          ))}
          {credits !== null && (
            <span className="ml-2 rounded-full border border-border bg-card px-3 py-1 text-[12px] tabular-nums">
              {credits} credits
            </span>
          )}
        </nav>
      </div>
    </header>
  );
}