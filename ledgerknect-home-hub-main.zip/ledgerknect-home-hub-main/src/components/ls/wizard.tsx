import { ArrowLeft, ArrowRight } from "lucide-react";
import type { ReactNode } from "react";
import { cn } from "@/lib/utils";

export interface WizardStep {
  id: string;
  title: string;
  subtitle: string;
  render: () => ReactNode;
  isValid?: boolean;
}

export function WizardShell({
  eyebrow,
  steps,
  index,
  onIndexChange,
  onSubmit,
  submitLabel,
}: {
  eyebrow: string;
  steps: WizardStep[];
  index: number;
  onIndexChange: (i: number) => void;
  onSubmit: () => void;
  submitLabel: string;
}) {
  const step = steps[index]!;
  const last = index === steps.length - 1;
  const valid = step.isValid !== false;
  const pct = Math.round(((index + 1) / steps.length) * 100);

  return (
    <div className="mx-auto grid w-full max-w-6xl gap-10 px-5 py-10 lg:grid-cols-[240px_1fr] lg:py-16">
      <aside className="lg:sticky lg:top-24 lg:self-start">
        <p className="text-[11px] font-semibold uppercase tracking-[0.2em] text-muted-foreground">
          {eyebrow}
        </p>
        <ol className="mt-5 space-y-1">
          {steps.map((s, i) => (
            <li key={s.id}>
              <button
                type="button"
                onClick={() => i <= index && onIndexChange(i)}
                className={cn(
                  "flex w-full items-center gap-3 rounded-md px-2.5 py-2 text-left text-[13px] transition-colors",
                  i === index
                    ? "bg-primary text-primary-foreground"
                    : i < index
                      ? "text-foreground hover:bg-accent/50"
                      : "text-muted-foreground/70",
                )}
              >
                <span
                  className={cn(
                    "grid size-5 shrink-0 place-items-center rounded-full border text-[10px] font-semibold",
                    i === index
                      ? "border-primary-foreground/40"
                      : i < index
                        ? "border-gold bg-gold text-gold-foreground"
                        : "border-border",
                  )}
                >
                  {i + 1}
                </span>
                {s.title}
              </button>
            </li>
          ))}
        </ol>
      </aside>

      <div>
        <div className="mb-8">
          <div className="h-[3px] w-full rounded-full bg-border">
            <div
              className="h-full rounded-full bg-gold transition-all duration-500"
              style={{ width: `${pct}%` }}
            />
          </div>
          <div className="mt-2 flex justify-between text-xs text-muted-foreground">
            <span>
              Step {index + 1} of {steps.length}
            </span>
            <span>{pct}% complete</span>
          </div>
        </div>

        <h1 className="text-3xl lg:text-4xl">{step.title}</h1>
        <p className="mt-2 max-w-2xl text-sm text-muted-foreground">{step.subtitle}</p>

        <div className="mt-8 space-y-8 rounded-xl border border-border bg-surface p-6 lg:p-8">
          {step.render()}
        </div>

        <div className="mt-8 flex items-center justify-between gap-4">
          <button
            type="button"
            disabled={index === 0}
            onClick={() => onIndexChange(index - 1)}
            className="inline-flex items-center gap-2 rounded-md border border-border px-4 py-2.5 text-sm transition-colors hover:bg-accent/50 disabled:opacity-40"
          >
            <ArrowLeft className="size-4" /> Back
          </button>
          <button
            type="button"
            disabled={!valid}
            onClick={() => (last ? onSubmit() : onIndexChange(index + 1))}
            className="inline-flex items-center gap-2 rounded-md bg-primary px-5 py-2.5 text-sm font-medium text-primary-foreground transition-opacity hover:opacity-90 disabled:opacity-40"
          >
            {last ? submitLabel : "Continue"} <ArrowRight className="size-4" />
          </button>
        </div>
        {!valid && (
          <p className="mt-3 text-right text-xs text-destructive">
            Please complete the mandatory fields on this step.
          </p>
        )}
      </div>
    </div>
  );
}