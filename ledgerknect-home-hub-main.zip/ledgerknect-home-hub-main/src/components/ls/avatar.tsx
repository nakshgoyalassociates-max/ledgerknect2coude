import { useState } from "react";
import { initials } from "@/lib/ledgerskill/testimonials";
import { cn } from "@/lib/utils";

export function Avatar({
  name,
  src,
  className,
  textClassName,
}: {
  name: string;
  src?: string;
  className?: string;
  textClassName?: string;
}) {
  const [error, setError] = useState(false);

  if (src && !error) {
    return (
      <img
        src={src}
        alt={name}
        onError={() => setError(true)}
        className={cn("rounded-full object-cover", className)}
      />
    );
  }

  return (
    <span
      className={cn(
        "flex items-center justify-center rounded-full bg-accent font-semibold uppercase tracking-tight",
        className,
      )}
      aria-label={name}
      title={name}
    >
      <span className={cn("leading-none", textClassName)}>{initials(name)}</span>
    </span>
  );
}
