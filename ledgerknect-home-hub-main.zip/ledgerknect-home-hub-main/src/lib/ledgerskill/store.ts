import { DEFAULT_WEIGHTS } from "./data";
import type { CandidateProfile, ClientRequirement, Weights } from "./types";
import { SEED_CANDIDATES } from "./seed";

const CAND_KEY = "ledgerskill.candidates";
const REQ_KEY = "ledgerskill.requirements";
const WEIGHT_KEY = "ledgerskill.weights";

const isBrowser = () => typeof window !== "undefined";

function read<T>(key: string, fallback: T): T {
  if (!isBrowser()) return fallback;
  try {
    const raw = window.localStorage.getItem(key);
    return raw ? (JSON.parse(raw) as T) : fallback;
  } catch {
    return fallback;
  }
}

function write(key: string, value: unknown) {
  if (!isBrowser()) return;
  window.localStorage.setItem(key, JSON.stringify(value));
}

export function getCandidates(): CandidateProfile[] {
  const stored = read<CandidateProfile[] | null>(CAND_KEY, null);
  if (!stored) return SEED_CANDIDATES;
  return [...stored, ...SEED_CANDIDATES];
}

export function saveCandidate(c: CandidateProfile) {
  const stored = read<CandidateProfile[]>(CAND_KEY, []);
  write(CAND_KEY, [c, ...stored.filter((x) => x.id !== c.id)]);
}

export function getRequirements(): ClientRequirement[] {
  return read<ClientRequirement[]>(REQ_KEY, []);
}

export function saveRequirement(r: ClientRequirement) {
  const stored = read<ClientRequirement[]>(REQ_KEY, []);
  write(REQ_KEY, [r, ...stored.filter((x) => x.id !== r.id)]);
}

export function getWeights(): Weights {
  return { ...DEFAULT_WEIGHTS, ...read<Partial<Weights>>(WEIGHT_KEY, {}) };
}

export function saveWeights(w: Weights) {
  write(WEIGHT_KEY, w);
}

export function newId() {
  return Math.random().toString(36).slice(2, 10);
}