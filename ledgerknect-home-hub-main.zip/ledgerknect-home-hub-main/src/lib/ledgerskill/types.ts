import type { PriorityField, Weights } from "./data";

export type AreaEntry = { name: string; years: string };
export type SkillEntry = { name: string; proficiency: string };

export interface CandidateProfile {
  id: string;
  createdAt: number;
  userType: string;
  fullName: string;
  mobile: string;
  email: string;
  location: string;
  preferredLocations: string[];
  workMode: string;
  managementLevel: string;
  designation: string;
  designationOther: string;
  totalExperience: string;
  primaryExperience: AreaEntry[];
  secondaryExperience: AreaEntry[];
  primarySkills: SkillEntry[];
  secondarySkills: SkillEntry[];
  qualification: string;
  professionalStatus: string;
  certifications: string[];
  software: string[];
  softwareProficiency: string;
  industries: string[];
  primaryIndustry: string;
  engagementTypes: string[];
  durations: string[];
  availability: string;
  weeklyAvailability: string;
  salaryBand: string;
  expectedSalary: string;
  minimumSalary: string;
  billingMethod: string;
  expectedRate: string;
  minimumRate: string;
  resumeName: string;
  headline: string;
  summary: string;
}

export interface ClientRequirement {
  id: string;
  createdAt: number;
  userType: string;
  companyName: string;
  contactPerson: string;
  mobile: string;
  email: string;
  companyLocation: string;
  industry: string;
  companySize: string;
  turnover: string;
  requirementType: string;
  assignmentTitle: string;
  assignmentTypes: string[];
  headcount: string;
  deployment: string;
  managementLevel: string;
  primaryExperience: AreaEntry[];
  secondaryExperience: AreaEntry[];
  primarySkills: string[];
  secondarySkills: string[];
  salaryBand: string;
  maxSalary: string;
  billingMethod: string;
  budget: string;
  mandatoryQualifications: string[];
  preferredQualifications: string[];
  mandatorySoftware: string[];
  preferredSoftware: string[];
  primaryIndustry: string;
  preferredIndustries: string[];
  workMode: string;
  locations: string[];
  engagementTypes: string[];
  durations: string[];
  startDate: string;
  weeklyRequirement: string;
  description: string;
  priorities: Record<PriorityField, "Mandatory" | "Preferred">;
}

export interface MatchBreakdownRow {
  parameter: string;
  score: number;
  weight: number;
}

export interface MatchResult {
  candidate: CandidateProfile;
  score: number;
  category: string;
  eligible: boolean;
  breakdown: MatchBreakdownRow[];
  explanation: string;
  gaps: string[];
  blockers: string[];
}

export type { Weights, PriorityField };