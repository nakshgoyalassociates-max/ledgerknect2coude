export interface VacancyAd {
  id: string;
  createdAt: number;
  posterType: "Employer" | "Professional";
  position: string;
  company: string;
  location: string;
  engagement: string;
  content: string;
  contactEmail: string;
  contactMobile: string;
}

const ADS_KEY = "ledgerskill.ads";

const isBrowser = () => typeof window !== "undefined";

export const SEED_ADS: VacancyAd[] = [
  {
    id: "ad-1",
    createdAt: 0,
    posterType: "Employer",
    position: "Manager — Statutory Audit",
    company: "Verma & Associates (CA Firm)",
    location: "Delhi",
    engagement: "Assignment / Project",
    content:
      "Statutory audit of 4 manufacturing clients for FY 2025-26. Team of 2 articles will support. CA qualified with 4+ years of audit experience, Tally & SAP exposure preferred. On-site at client premises in Delhi and Ghaziabad. Duration 3 months, extendable.",
    contactEmail: "hiring@vermaassociates.example.com",
    contactMobile: "98110 44556",
  },
  {
    id: "ad-2",
    createdAt: 0,
    posterType: "Employer",
    position: "Finance Controller",
    company: "Northline Logistics Pvt Ltd",
    location: "Gurugram",
    engagement: "Full-Time",
    content:
      "Own monthly closing, MIS, budgeting and banking relationships for a 300-crore logistics business. Reporting to the CFO, team of 6. CA with 8–12 years' experience, ERP migration exposure a plus. Budget 24–30 LPA.",
    contactEmail: "careers@northline.example.com",
    contactMobile: "98999 22110",
  },
  {
    id: "ad-3",
    createdAt: 0,
    posterType: "Professional",
    position: "Available — Fractional CFO (2–3 days/week)",
    company: "Independent practitioner",
    location: "Noida · Hybrid",
    engagement: "Fractional / Part-Time",
    content:
      "Ex-CFO with 15 years across manufacturing and SaaS. Available for fundraising support, MIS build-out, board reporting and controls clean-up. Delhi NCR clients preferred, 2–3 days a week.",
    contactEmail: "cfo.services@example.com",
    contactMobile: "98730 55442",
  },
];

function read(): VacancyAd[] {
  if (!isBrowser()) return [];
  try {
    const raw = window.localStorage.getItem(ADS_KEY);
    return raw ? (JSON.parse(raw) as VacancyAd[]) : [];
  } catch {
    return [];
  }
}

export function getAds(): VacancyAd[] {
  return [...read(), ...SEED_ADS];
}

export function saveAd(ad: VacancyAd) {
  if (!isBrowser()) return;
  window.localStorage.setItem(ADS_KEY, JSON.stringify([ad, ...read()]));
}

export const AD_ENGAGEMENTS = [
  "Full-Time",
  "Contract",
  "Assignment / Project",
  "Fractional / Part-Time",
  "Manpower Supply",
];
