export interface Testimonial {
  id: string;
  candidateId: string;
  author: string;
  role: string;
  text: string;
}

const KEY = "ledgerskill.testimonials";

const isBrowser = () => typeof window !== "undefined";

export const SEED_TESTIMONIALS: Testimonial[] = [
  {
    id: "t-1",
    candidateId: "seed-1",
    author: "Rohit Malhotra",
    role: "Finance Head, Ecoline Industries",
    text: "Took full ownership of our GST reconciliations and cleared a two-year backlog in one quarter. Notices dropped to zero.",
  },
  {
    id: "t-2",
    candidateId: "seed-1",
    author: "CA Neha Gupta",
    role: "Partner, Gupta & Co.",
    text: "Reliable on deadlines and excellent with departmental correspondence. We deploy him on our larger clients without supervision.",
  },
  {
    id: "t-3",
    candidateId: "seed-2",
    author: "Sandeep Rao",
    role: "Founder, Brightwork SaaS",
    text: "Built our MIS and board pack from scratch and steered us through a Series A diligence. Worth every day of the engagement.",
  },
];

function read(): Testimonial[] {
  if (!isBrowser()) return [];
  try {
    const raw = window.localStorage.getItem(KEY);
    return raw ? (JSON.parse(raw) as Testimonial[]) : [];
  } catch {
    return [];
  }
}

export function getTestimonials(candidateId: string): Testimonial[] {
  return [...read(), ...SEED_TESTIMONIALS].filter((t) => t.candidateId === candidateId);
}

export function saveTestimonial(t: Testimonial) {
  if (!isBrowser()) return;
  window.localStorage.setItem(KEY, JSON.stringify([t, ...read()]));
}

export function initials(name: string) {
  return name
    .split(" ")
    .filter(Boolean)
    .slice(0, 2)
    .map((p) => p[0]?.toUpperCase() ?? "")
    .join("");
}
