export const DEFAULT_CREDITS = 10;
export const REVEAL_COST = 1;

const BAL_KEY = "ledgerskill.credits";
const UNLOCK_KEY = "ledgerskill.unlocked";
export const CREDITS_EVENT = "ledgerskill:credits";

export const VIEWER = "viewer";

const isBrowser = () => typeof window !== "undefined";

function read<T>(key: string, fallback: T): T {
  if (!isBrowser()) return fallback;
  try {
    const raw = window.localStorage.getItem(key);
    return raw ? (JSON.parse(raw) as T) : fallback;
  } catch {
    return fallback;
  }
}

function write(key: string, value: unknown) {
  if (!isBrowser()) return;
  window.localStorage.setItem(key, JSON.stringify(value));
  window.dispatchEvent(new CustomEvent(CREDITS_EVENT));
}

export function getBalances(): Record<string, number> {
  return read<Record<string, number>>(BAL_KEY, {});
}

export function getBalance(accountId: string = VIEWER): number {
  const balances = getBalances();
  return balances[accountId] ?? DEFAULT_CREDITS;
}

export function addCredits(accountId: string, amount: number) {
  const balances = getBalances();
  balances[accountId] = Math.max(0, getBalance(accountId) + amount);
  write(BAL_KEY, balances);
  return balances[accountId];
}

function getUnlockedMap(): Record<string, true> {
  return read<Record<string, true>>(UNLOCK_KEY, {});
}

export function isUnlocked(contactId: string): boolean {
  return Boolean(getUnlockedMap()[contactId]);
}

export type UnlockResult = "unlocked" | "already" | "insufficient";

export function unlockContact(
  contactId: string,
  accountId: string = VIEWER,
): UnlockResult {
  if (isUnlocked(contactId)) return "already";
  const balance = getBalance(accountId);
  if (balance < REVEAL_COST) return "insufficient";
  const balances = getBalances();
  balances[accountId] = balance - REVEAL_COST;
  if (isBrowser()) window.localStorage.setItem(BAL_KEY, JSON.stringify(balances));
  const unlocked = getUnlockedMap();
  unlocked[contactId] = true;
  write(UNLOCK_KEY, unlocked);
  return "unlocked";
}

export function maskEmail(value: string): string {
  if (!value.includes("@")) return "••••••••";
  const [user = "", domain = ""] = value.split("@");
  const dot = domain.lastIndexOf(".");
  const tld = dot > -1 ? domain.slice(dot) : "";
  return `${user.slice(0, 2)}••••@••••${tld}`;
}

export function maskPhone(value: string): string {
  const digits = value.replace(/\D/g, "");
  if (digits.length < 4) return "••••••••";
  return `${digits.slice(0, 2)}••••••${digits.slice(-2)}`;
}

export function maskText(value: string): string {
  if (!value) return "••••••••";
  return `${value.slice(0, 1)}•••••••`;
}
