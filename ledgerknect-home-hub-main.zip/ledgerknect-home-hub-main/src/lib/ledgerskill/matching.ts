import { DEFAULT_WEIGHTS, EXPERIENCE_RANGES, MANAGEMENT_LEVELS, SALARY_BANDS } from "./data";
import type {
  AreaEntry,
  CandidateProfile,
  ClientRequirement,
  MatchBreakdownRow,
  MatchResult,
  Weights,
} from "./types";

const rangeIndex = (v: string) => Math.max(0, EXPERIENCE_RANGES.indexOf(v));
const salaryIndex = (v: string) => SALARY_BANDS.indexOf(v);
const levelIndex = (v: string) => MANAGEMENT_LEVELS.indexOf(v as never);

function overlapScore(candidate: string[], required: string[]): number {
  if (required.length === 0) return 100;
  const set = new Set(candidate.map((s) => s.toLowerCase()));
  const hits = required.filter((r) => set.has(r.toLowerCase())).length;
  return Math.round((hits / required.length) * 100);
}

/** Skill overlap where a candidate's secondary skills partially satisfy a requirement. */
function skillScore(primary: string[], secondary: string[], required: string[]): number {
  if (required.length === 0) return 100;
  const p = new Set(primary.map((s) => s.toLowerCase()));
  const s = new Set(secondary.map((x) => x.toLowerCase()));
  let total = 0;
  for (const r of required) {
    const k = r.toLowerCase();
    if (p.has(k)) total += 1;
    else if (s.has(k)) total += 0.5;
  }
  return Math.round((total / required.length) * 100);
}

function experienceScore(candidate: AreaEntry[], required: AreaEntry[]): number {
  if (required.length === 0) return 100;
  const map = new Map(candidate.map((c) => [c.name.toLowerCase(), rangeIndex(c.years)]));
  let total = 0;
  for (const req of required) {
    const have = map.get(req.name.toLowerCase());
    if (have === undefined) continue;
    const need = rangeIndex(req.years);
    if (have >= need) total += 1;
    else total += Math.max(0.4, 1 - (need - have) * 0.25);
  }
  return Math.round((total / required.length) * 100);
}

function salaryScore(c: CandidateProfile, r: ClientRequirement): number {
  const ci = salaryIndex(c.salaryBand);
  const ri = salaryIndex(r.salaryBand);
  if (ci < 0 || ri < 0) {
    const expected = Number(c.expectedSalary);
    const budget = Number(r.maxSalary);
    if (!expected || !budget) return 100;
    if (expected <= budget) return 100;
    return Math.max(0, Math.round((budget / expected) * 100));
  }
  if (ci <= ri) return 100;
  return Math.max(0, 100 - (ci - ri) * 30);
}

function managementScore(c: CandidateProfile, r: ClientRequirement): number {
  const ci = levelIndex(c.managementLevel);
  const ri = levelIndex(r.managementLevel);
  if (ci < 0 || ri < 0) return 100;
  const diff = Math.abs(ci - ri);
  return diff === 0 ? 100 : diff === 1 ? 60 : 25;
}

function engagementScore(c: CandidateProfile, r: ClientRequirement): number {
  const parts = [
    overlapScore(c.engagementTypes, r.engagementTypes),
    overlapScore(c.durations, r.durations),
    c.weeklyAvailability && r.weeklyRequirement
      ? c.weeklyAvailability === r.weeklyRequirement
        ? 100
        : 60
      : 100,
  ];
  return Math.round(parts.reduce((a, b) => a + b, 0) / parts.length);
}

function locationScore(c: CandidateProfile, r: ClientRequirement): number {
  const remoteOk = r.workMode === "Remote" || c.preferredLocations.includes("Remote");
  const modeOk = !r.workMode || !c.workMode || c.workMode === r.workMode || remoteOk;
  const locOk =
    r.locations.length === 0 ||
    remoteOk ||
    r.locations.some(
      (l) => c.preferredLocations.includes(l) || c.location === l,
    );
  return (modeOk ? 50 : 20) + (locOk ? 50 : 10);
}

export function categoryFor(score: number): string {
  if (score >= 90) return "Excellent Match";
  if (score >= 80) return "Strong Match";
  if (score >= 70) return "Good Match";
  if (score >= 60) return "Potential Match";
  return "Low Match";
}

export function matchCandidate(
  candidate: CandidateProfile,
  req: ClientRequirement,
  weights: Weights = DEFAULT_WEIGHTS,
): MatchResult {
  const candPrimarySkills = candidate.primarySkills.map((s) => s.name);
  const candSecondarySkills = candidate.secondarySkills.map((s) => s.name);

  const scores: Record<keyof Weights, number> = {
    primarySkills: skillScore(candPrimarySkills, candSecondarySkills, req.primarySkills),
    primaryExperience: experienceScore(candidate.primaryExperience, req.primaryExperience),
    salary: salaryScore(candidate, req),
    managementLevel: managementScore(candidate, req),
    secondarySkills: skillScore(
      [...candSecondarySkills, ...candPrimarySkills],
      [],
      req.secondarySkills,
    ),
    secondaryExperience: experienceScore(
      [...candidate.secondaryExperience, ...candidate.primaryExperience],
      req.secondaryExperience,
    ),
    engagement: engagementScore(candidate, req),
    location: locationScore(candidate, req),
  };

  const keys = Object.keys(scores) as (keyof Weights)[];
  const totalWeight = keys.reduce((a, k) => a + weights[k], 0) || 1;
  const score = Math.round(
    keys.reduce((a, k) => a + scores[k] * weights[k], 0) / totalWeight,
  );

  const breakdown: MatchBreakdownRow[] = keys.map((k) => ({
    parameter: k,
    score: scores[k],
    weight: weights[k],
  }));

  // Step 1 — Eligibility check against Mandatory priorities.
  const blockers: string[] = [];
  const p = req.priorities;
  const qualOk =
    req.mandatoryQualifications.length === 0 ||
    req.mandatoryQualifications.includes(candidate.qualification);
  if (p.Qualification === "Mandatory" && !qualOk)
    blockers.push(`Qualification ${req.mandatoryQualifications.join(" / ")} required`);
  if (p["Primary Skills"] === "Mandatory" && scores.primarySkills < 100)
    blockers.push("Does not hold every mandatory primary skill");
  if (p["Secondary Skills"] === "Mandatory" && scores.secondarySkills < 100)
    blockers.push("Missing mandatory secondary skills");
  if (p.Experience === "Mandatory" && scores.primaryExperience < 100)
    blockers.push("Relevant experience below the mandatory requirement");
  if (p["Management Level"] === "Mandatory" && scores.managementLevel < 100)
    blockers.push(`Required management level: ${req.managementLevel}`);
  const softwareOk =
    req.mandatorySoftware.length === 0 ||
    req.mandatorySoftware.every((s) => candidate.software.includes(s));
  if (p.Software === "Mandatory" && !softwareOk)
    blockers.push(`Mandatory software: ${req.mandatorySoftware.join(", ")}`);
  const industryOk =
    !req.primaryIndustry || candidate.industries.includes(req.primaryIndustry);
  if (p.Industry === "Mandatory" && !industryOk)
    blockers.push(`No exposure to ${req.primaryIndustry}`);
  if (p.Location === "Mandatory" && scores.location < 100)
    blockers.push("Location / work mode does not match");
  if (p.Availability === "Mandatory" && scores.engagement < 70)
    blockers.push("Availability does not meet the requirement");
  if (
    p["Engagement Type"] === "Mandatory" &&
    overlapScore(candidate.engagementTypes, req.engagementTypes) < 100
  )
    blockers.push("Engagement type not accepted by the candidate");
  const gaps: string[] = [];
  if (scores.salary < 100)
    gaps.push("Expected compensation is above the client's stated budget");
  if (scores.primarySkills < 100) gaps.push("Not all required primary skills are held");
  if (scores.primaryExperience < 100)
    gaps.push("Relevant experience is slightly below the required range");
  if (scores.managementLevel < 100) gaps.push("Management level differs from the requirement");
  if (scores.location < 100) gaps.push("Location or work mode preference differs");
  if (!softwareOk) gaps.push("Some required software/ERP exposure is missing");
  if (!industryOk && req.primaryIndustry)
    gaps.push(`Limited exposure to ${req.primaryIndustry}`);

  const eligible = blockers.length === 0;
  const category = eligible ? categoryFor(score) : "Not Eligible";

  const strengths: string[] = [];
  if (scores.primarySkills >= 90) strengths.push("primary expertise");
  if (scores.primaryExperience >= 90) strengths.push("relevant experience");
  if (scores.managementLevel === 100) strengths.push("management level");
  if (scores.salary === 100) strengths.push("compensation expectation");

  const explanation = !eligible
    ? `Not Eligible: ${blockers[0]}.`
    : `${category}: The candidate's ${
        strengths.length ? strengths.join(", ") : "profile"
      } align with the requirement.${
        gaps.length ? ` Key gap: ${gaps[0]}.` : ""
      }`;

  return {
    candidate,
    score: eligible ? score : Math.min(score, 59),
    category,
    eligible,
    breakdown,
    explanation,
    gaps,
    blockers,
  };
}

export function rankCandidates(
  candidates: CandidateProfile[],
  req: ClientRequirement,
  weights?: Weights,
): MatchResult[] {
  return candidates
    .map((c) => matchCandidate(c, req, weights))
    .sort((a, b) => Number(b.eligible) - Number(a.eligible) || b.score - a.score);
}