// LedgerKnect V1 master data — Delhi NCR

export const USER_TYPES = [
  "Candidate / Employee",
  "CA / Finance Professional",
  "Finance Consultant",
  "Company / Employer",
  "Business / Client",
  "CA Firm / Consulting Firm",
  "Finance Practitioner (needs manpower)",
  "Back Office / Outsourcing Company",
  "Staffing / Manpower Supply Partner",
] as const;

/** How the client wants to engage talent. */
export const REQUIREMENT_TYPES = [
  "Permanent Hiring",
  "Project / Assignment Based",
  "Manpower Supply / Deputation",
  "Outsourced Back Office Team",
  "Interim / Temporary Cover",
] as const;

export const ASSIGNMENT_TYPES = [
  "Statutory Audit",
  "Internal Audit",
  "Tax Audit",
  "GST Audit",
  "Accounting / Bookkeeping",
  "Month-End / Year-End Closing",
  "GST Filing & Reconciliation",
  "TDS & Income Tax Filing",
  "Payroll Processing",
  "MIS & Reporting",
  "Budgeting & Forecasting",
  "Financial Modelling",
  "Due Diligence",
  "Virtual CFO",
  "ERP / Tally Migration",
  "Books Clean-up & Compliance Catch-up",
  "Other",
];

export const DEPLOYMENT_MODELS = [
  "At our office",
  "At end-client site",
  "Off-site / our back office",
  "Remote",
];

export const HEADCOUNTS = ["1", "2–3", "4–5", "6–10", "10+"];

export const PROFESSIONAL_TYPES = USER_TYPES.slice(0, 3);
export const CLIENT_TYPES = USER_TYPES.slice(3);

export const LOCATIONS = [
  "Delhi",
  "Noida",
  "Greater Noida",
  "Ghaziabad",
  "Gurugram",
  "Faridabad",
  "Other Delhi NCR",
];

export const PREFERRED_LOCATIONS = [
  "Delhi",
  "Noida",
  "Greater Noida",
  "Ghaziabad",
  "Gurugram",
  "Faridabad",
  "Remote",
];

export const WORK_MODES = ["On-site", "Hybrid", "Remote"];

export const MANAGEMENT_LEVELS = [
  "Senior Management",
  "Mid-Level Management",
  "Executive / Operational",
] as const;

export const DESIGNATIONS: Record<string, string[]> = {
  "Senior Management": [
    "CFO",
    "Finance Director",
    "Head of Finance",
    "Financial Controller",
    "VP Finance",
    "Finance Head",
    "Partner",
    "Other",
  ],
  "Mid-Level Management": [
    "Finance Manager",
    "Senior Finance Manager",
    "Accounts Manager",
    "Tax Manager",
    "Audit Manager",
    "Finance Controller",
    "Assistant Finance Manager",
    "Other",
  ],
  "Executive / Operational": [
    "Accountant",
    "Senior Accountant",
    "Accounts Executive",
    "Finance Executive",
    "GST Executive",
    "Tax Executive",
    "MIS Executive",
    "Accounts Assistant",
    "Other",
  ],
};

export const TOTAL_EXPERIENCE = [
  "Fresher",
  "0–2 years",
  "3–5 years",
  "6–10 years",
  "11–15 years",
  "16–20 years",
  "20+ years",
];

export const EXPERIENCE_RANGES = [
  "0–2 years",
  "3–5 years",
  "6–10 years",
  "11–15 years",
  "16–20 years",
  "20+ years",
];

export const EXPERIENCE_AREAS = [
  "Accounting",
  "Financial Reporting",
  "GST",
  "Direct Tax / Income Tax",
  "Audit",
  "Internal Audit",
  "FP&A",
  "MIS & Reporting",
  "Corporate Finance",
  "Treasury",
  "Financial Analysis",
  "Management Accounting",
  "Cost Accounting",
  "CFO / Virtual CFO",
  "Tax Advisory",
  "Compliance",
  "Payroll",
  "Working Capital",
  "Financial Modelling",
  "Business Advisory",
];

export const SKILL_GROUPS: { group: string; skills: string[] }[] = [
  {
    group: "Accounting",
    skills: [
      "Bookkeeping",
      "General Ledger",
      "Accounts Payable",
      "Accounts Receivable",
      "Bank Reconciliation",
      "Ledger Reconciliation",
      "Month-End Closing",
      "Financial Statements",
      "Consolidation",
      "Fixed Assets",
      "Inventory Accounting",
      "Cost Accounting",
    ],
  },
  {
    group: "GST",
    skills: [
      "GST Return Filing",
      "GST Reconciliation",
      "GST Advisory",
      "GST Audit",
      "GST Assessment",
      "GST Notice Handling",
      "GST Litigation Support",
      "Input Tax Credit",
      "E-Invoicing",
      "E-Way Bill",
    ],
  },
  {
    group: "Tax",
    skills: [
      "TDS",
      "Income Tax Return",
      "Income Tax Assessment",
      "Tax Audit",
      "Direct Tax Advisory",
      "International Tax",
      "Transfer Pricing",
      "Tax Planning",
    ],
  },
  {
    group: "Audit",
    skills: [
      "Statutory Audit",
      "Internal Audit",
      "Stock Audit",
      "Process Audit",
      "Compliance Audit",
      "Concurrent Audit",
      "Risk Advisory",
      "Internal Controls",
      "Due Diligence",
    ],
  },
  {
    group: "Finance",
    skills: [
      "Budgeting",
      "Forecasting",
      "Financial Planning",
      "Financial Analysis",
      "Cash Flow Management",
      "Working Capital",
      "MIS",
      "Management Reporting",
      "Financial Modelling",
      "Business Planning",
      "Cost Analysis",
      "Fund Raising",
      "Banking & Finance",
      "Investor Reporting",
      "Board Reporting",
    ],
  },
  {
    group: "CFO / Advisory",
    skills: [
      "Virtual CFO",
      "Fractional CFO",
      "Financial Strategy",
      "Business Advisory",
      "Working Capital Advisory",
      "Business Performance",
      "Finance Transformation",
      "Process Improvement",
    ],
  },
];

export const ALL_SKILLS = SKILL_GROUPS.flatMap((g) => g.skills);

export const PROFICIENCY = ["Basic", "Intermediate", "Advanced", "Expert"];

export const QUALIFICATIONS = [
  "CA",
  "CMA",
  "CS",
  "ACCA",
  "CFA",
  "MBA Finance",
  "M.Com",
  "B.Com",
  "LLB",
  "Other",
];

export const PROFESSIONAL_STATUS = [
  "Qualified",
  "Part Qualified",
  "Pursuing",
  "Not Applicable",
];

export const CERTIFICATIONS = [
  "NISM",
  "IFRS",
  "GST Certification",
  "SAP",
  "Financial Modelling",
  "Power BI",
  "Other",
];

export const SOFTWARE_GROUPS: { group: string; items: string[] }[] = [
  {
    group: "Accounting Software",
    items: [
      "Tally",
      "Tally Prime",
      "Zoho Books",
      "QuickBooks",
      "Busy",
      "Marg",
      "Xero",
      "Other",
    ],
  },
  {
    group: "ERP",
    items: [
      "SAP",
      "SAP Business One",
      "Oracle",
      "Microsoft Dynamics",
      "NetSuite",
      "ERPNext",
      "Other ERP",
    ],
  },
  {
    group: "Analytics / Reporting",
    items: [
      "MS Excel",
      "Advanced Excel",
      "Power BI",
      "Tableau",
      "Looker Studio",
      "SQL",
      "Python",
      "Other Analytics",
    ],
  },
];

export const ALL_SOFTWARE = SOFTWARE_GROUPS.flatMap((g) => g.items);

export const INDUSTRIES = [
  "Manufacturing",
  "Textile & Garments",
  "Export",
  "Import",
  "Trading",
  "Retail",
  "E-commerce",
  "IT / ITES",
  "SaaS / Technology",
  "Startup",
  "BFSI",
  "Real Estate",
  "Construction",
  "Healthcare",
  "Hospitality",
  "Education",
  "Logistics",
  "Professional Services",
  "NGO",
  "Other",
];

export const ENGAGEMENT_TYPES = [
  "Permanent Employment",
  "Full-Time",
  "Part-Time",
  "Temporary",
  "Contract",
  "Project",
  "Freelance",
  "Consulting",
  "Advisory",
  "Fractional",
  "Hourly",
  "Retainer",
];

export const DURATIONS = [
  "One-Time",
  "Less than 1 Month",
  "1–3 Months",
  "3–6 Months",
  "Ongoing",
];

export const AVAILABILITY = [
  "Immediately",
  "Within 15 Days",
  "Within 30 Days",
];

export const CLIENT_AVAILABILITY = [
  "Immediately",
  "Within 15 Days",
  "Within 30 Days",
  "Flexible",
];

export const SALARY_BANDS = [
  "Below ₹3 Lakh",
  "₹3–5 Lakh",
  "₹5–8 Lakh",
  "₹8–12 Lakh",
  "₹12–20 Lakh",
  "₹20–30 Lakh",
  "₹30–50 Lakh",
  "₹50 Lakh+",
];

export const BILLING_METHODS = ["Hourly", "Daily", "Monthly", "Project", "Retainer"];

export const COMPANY_SIZES = ["1–10", "11–50", "51–100", "101–250", "251–500", "500+"];

export const TURNOVERS = [
  "Below ₹1 Cr",
  "₹1–5 Cr",
  "₹5–10 Cr",
  "₹10–25 Cr",
  "₹25–50 Cr",
  "₹50–100 Cr",
  "₹100–500 Cr",
  "₹500 Cr+",
];

export const PRIORITY_FIELDS = [
  "Qualification",
  "Primary Skills",
  "Secondary Skills",
  "Experience",
  "Management Level",
  "Industry",
  "Software",
  "Location",
  "Availability",
  "Engagement Type",
] as const;

export type PriorityField = (typeof PRIORITY_FIELDS)[number];

/** Default matching weights (configurable from the Admin Panel). */
export const DEFAULT_WEIGHTS = {
  primarySkills: 30,
  primaryExperience: 25,
  salary: 10,
  managementLevel: 10,
  secondarySkills: 10,
  secondaryExperience: 10,
  engagement: 3,
  location: 2,
};

export type Weights = typeof DEFAULT_WEIGHTS;

export const WEIGHT_LABELS: Record<keyof Weights, string> = {
  primarySkills: "Primary Skills",
  primaryExperience: "Primary Experience",
  salary: "Salary / Compensation",
  managementLevel: "Management Level",
  secondarySkills: "Secondary Skills",
  secondaryExperience: "Secondary Experience",
  engagement: "Engagement / Availability",
  location: "Location / Work Mode",
};