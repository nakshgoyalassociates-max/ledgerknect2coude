import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { toast } from "sonner";
import { Avatar } from "@/components/ls/avatar";
import { SiteHeader } from "@/components/ls/site-header";
import { ContactReveal } from "@/components/ls/contact-reveal";
import { TextAreaField, TextField } from "@/components/ls/fields";
import { getCandidates } from "@/lib/ledgerskill/store";
import { newId } from "@/lib/ledgerskill/store";
import {
  getTestimonials,
  initials,
  saveTestimonial,
  type Testimonial,
} from "@/lib/ledgerskill/testimonials";
import type { CandidateProfile } from "@/lib/ledgerskill/types";

export const Route = createFileRoute("/profile/$id")({
  head: () => ({
    meta: [
      { title: "Professional profile | LedgerKnect" },
      {
        name: "description",
        content:
          "Full finance professional profile: skills, experience areas, credentials, software, engagement preferences and compensation.",
      },
      { property: "og:title", content: "Professional profile | LedgerKnect" },
      {
        property: "og:description",
        content: "Drill down into a finance professional's complete LedgerKnect profile.",
      },
    ],
  }),
  component: ProfilePage,
});

function ProfilePage() {
  const { id } = Route.useParams();
  const [ready, setReady] = useState(false);
  const [candidate, setCandidate] = useState<CandidateProfile | null>(null);
  const [quotes, setQuotes] = useState<Testimonial[]>([]);

  useEffect(() => {
    setCandidate(getCandidates().find((c) => c.id === id) ?? null);
    setQuotes(getTestimonials(id));
    setReady(true);
  }, [id]);

  return (
    <div className="min-h-screen">
      <SiteHeader />
      <main className="mx-auto w-full max-w-5xl px-5 py-12">
        <Link to="/recruiters" search={{ tab: "talent" as const }} className="text-sm underline underline-offset-4">
          ← Back to find talent
        </Link>
        {!ready ? (
          <p className="mt-10 text-sm text-muted-foreground">Loading profile…</p>
        ) : !candidate ? (
          <p className="mt-10 text-sm text-muted-foreground">Profile not found.</p>
        ) : (
          <>
            <section className="mt-6 overflow-hidden rounded-xl border border-border bg-card">
              <div className="h-24 bg-primary/90" />
              <div className="px-6 pb-6">
                <div className="-mt-10 h-20 w-20">
                  <Avatar
                    name={candidate.fullName}
                    className="h-20 w-20 border-4 border-card bg-accent text-2xl"
                    textClassName="text-2xl"
                  />
                </div>
                <div className="mt-4 flex flex-wrap items-center gap-3">
                  <h1 className="text-4xl">{candidate.fullName}</h1>
                  {candidate.availability && (
                    <span className="rounded-full bg-accent px-3 py-1 text-[11px] font-semibold uppercase tracking-[0.12em]">
                      Open to work · {candidate.availability}
                    </span>
                  )}
                </div>
                <p className="mt-2 text-sm text-muted-foreground">
                  {candidate.headline ||
                    `${candidate.designation} · ${candidate.managementLevel}`}
                </p>
                <p className="mt-1 text-sm text-muted-foreground">
                  {[candidate.location, candidate.workMode, candidate.totalExperience]
                    .filter(Boolean)
                    .join(" · ")}
                </p>
                {candidate.summary && (
                  <p className="mt-4 max-w-3xl text-sm">{candidate.summary}</p>
                )}
                <div className="mt-5 flex flex-wrap items-center gap-x-6 gap-y-2 border-t border-border pt-4 text-xs">
                  <span className="flex items-center gap-2">
                    <span className="text-muted-foreground">Email</span>
                    <ContactReveal
                      contactId={`candidate:${candidate.id}:email`}
                      value={candidate.email}
                      kind="email"
                    />
                  </span>
                  <span className="flex items-center gap-2">
                    <span className="text-muted-foreground">Mobile</span>
                    <ContactReveal
                      contactId={`candidate:${candidate.id}:mobile`}
                      value={candidate.mobile}
                      kind="phone"
                    />
                  </span>
                </div>
              </div>
            </section>

            <Section title="Profile">
              <Row label="User type" value={candidate.userType} />
              <Row label="Designation" value={candidate.designation || candidate.designationOther} />
              <Row label="Management level" value={candidate.managementLevel} />
              <Row label="Total experience" value={candidate.totalExperience} />
              <Row label="Location" value={candidate.location} />
              <Row label="Preferred locations" value={candidate.preferredLocations.join(", ")} />
              <Row label="Work mode" value={candidate.workMode} />
            </Section>

            <Section title="Contact">
              <RowNode label="Email">
                <ContactReveal
                  contactId={`candidate:${candidate.id}:email`}
                  value={candidate.email}
                  kind="email"
                />
              </RowNode>
              <RowNode label="Mobile">
                <ContactReveal
                  contactId={`candidate:${candidate.id}:mobile`}
                  value={candidate.mobile}
                  kind="phone"
                />
              </RowNode>
              <Row label="Resume" value={candidate.resumeName} />
            </Section>

            <Section title="Skills">
              <Row
                label="Primary skills"
                value={candidate.primarySkills.map((s) => `${s.name} (${s.proficiency})`).join(", ")}
              />
              <Row
                label="Secondary skills"
                value={candidate.secondarySkills
                  .map((s) => `${s.name} (${s.proficiency})`)
                  .join(", ")}
              />
            </Section>

            <Section title="Experience areas">
              <Row
                label="Primary experience"
                value={candidate.primaryExperience.map((e) => `${e.name} (${e.years})`).join(", ")}
              />
              <Row
                label="Secondary experience"
                value={candidate.secondaryExperience.map((e) => `${e.name} (${e.years})`).join(", ")}
              />
            </Section>

            <Section title="Credentials & tools">
              <Row label="Qualification" value={candidate.qualification} />
              <Row label="Status" value={candidate.professionalStatus} />
              <Row label="Certifications" value={candidate.certifications.join(", ")} />
              <Row label="Software" value={candidate.software.join(", ")} />
              <Row label="Software proficiency" value={candidate.softwareProficiency} />
              <Row label="Industries" value={candidate.industries.join(", ")} />
              <Row label="Primary industry" value={candidate.primaryIndustry} />
            </Section>

            <Section title="Engagement & compensation">
              <Row label="Engagement types" value={candidate.engagementTypes.join(", ")} />
              <Row label="Durations" value={candidate.durations.join(", ")} />
              <Row label="Availability" value={candidate.availability} />
              <Row label="Weekly availability" value={candidate.weeklyAvailability} />
              <Row label="Salary band" value={candidate.salaryBand} />
              <Row label="Expected salary" value={candidate.expectedSalary} />
              <Row label="Minimum salary" value={candidate.minimumSalary} />
              <Row label="Billing method" value={candidate.billingMethod} />
              <Row label="Expected rate" value={candidate.expectedRate} />
              <Row label="Minimum rate" value={candidate.minimumRate} />
            </Section>

            <TestimonialsSection
              candidateId={candidate.id}
              quotes={quotes}
              onAdded={() => setQuotes(getTestimonials(candidate.id))}
            />
          </>
        )}
      </main>
    </div>
  );
}

function TestimonialsSection({
  candidateId,
  quotes,
  onAdded,
}: {
  candidateId: string;
  quotes: Testimonial[];
  onAdded: () => void;
}) {
  const [open, setOpen] = useState(false);
  const [author, setAuthor] = useState("");
  const [role, setRole] = useState("");
  const [text, setText] = useState("");

  const submit = () => {
    if (!author.trim() || !text.trim()) {
      toast.error("Name and the recommendation text are required.");
      return;
    }
    saveTestimonial({ id: newId(), candidateId, author, role, text });
    setAuthor("");
    setRole("");
    setText("");
    setOpen(false);
    onAdded();
    toast.success("Recommendation added.");
  };

  return (
    <section className="mt-8 rounded-xl border border-border bg-surface p-6">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <h2 className="text-xl">Testimonials & recommendations</h2>
        <button
          type="button"
          onClick={() => setOpen((o) => !o)}
          className="rounded-md border border-border px-4 py-2 text-xs font-medium hover:bg-accent/40"
        >
          {open ? "Cancel" : "Write a recommendation"}
        </button>
      </div>

      {open && (
        <div className="mt-5 space-y-5 rounded-lg border border-border bg-card p-5">
          <div className="grid gap-5 sm:grid-cols-2">
            <TextField label="Your name" required value={author} onChange={setAuthor} />
            <TextField
              label="Your role / company"
              value={role}
              onChange={setRole}
              placeholder="e.g. Finance Head, Ecoline Industries"
            />
          </div>
          <TextAreaField
            label="Recommendation"
            value={text}
            maxLength={600}
            onChange={setText}
            placeholder="What was it like working with this professional?"
          />
          <button
            type="button"
            onClick={submit}
            className="rounded-md bg-primary px-5 py-2.5 text-sm font-medium text-primary-foreground hover:opacity-90"
          >
            Post recommendation
          </button>
        </div>
      )}

      {quotes.length === 0 ? (
        <p className="mt-4 text-sm text-muted-foreground">No recommendations yet.</p>
      ) : (
        <ul className="mt-5 grid gap-4 sm:grid-cols-2">
          {quotes.map((q) => (
            <li key={q.id} className="rounded-lg border border-border bg-card p-5">
              <div className="flex items-center gap-3">
                <span className="flex h-9 w-9 items-center justify-center rounded-full bg-accent text-xs font-semibold">
                  {initials(q.author)}
                </span>
                <span>
                  <span className="block text-sm font-medium">{q.author}</span>
                  <span className="block text-xs text-muted-foreground">{q.role}</span>
                </span>
              </div>
              <p className="mt-3 text-sm">“{q.text}”</p>
            </li>
          ))}
        </ul>
      )}
    </section>
  );
}

function Section({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <section className="mt-8 rounded-xl border border-border bg-surface p-6">
      <h2 className="text-xl">{title}</h2>
      <dl className="mt-4 grid gap-4 text-sm sm:grid-cols-2">{children}</dl>
    </section>
  );
}

function Row({ label, value }: { label: string; value: string }) {
  return (
    <div>
      <dt className="text-[11px] font-semibold uppercase tracking-[0.14em] text-muted-foreground">
        {label}
      </dt>
      <dd className="mt-1">{value || "—"}</dd>
    </div>
  );
}

function RowNode({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div>
      <dt className="text-[11px] font-semibold uppercase tracking-[0.14em] text-muted-foreground">
        {label}
      </dt>
      <dd className="mt-1">{children}</dd>
    </div>
  );
}
