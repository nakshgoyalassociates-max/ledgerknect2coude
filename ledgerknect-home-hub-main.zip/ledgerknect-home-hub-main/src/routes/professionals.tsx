import { createFileRoute } from "@tanstack/react-router";
import { SiteHeader } from "@/components/ls/site-header";
import { OpportunitySearchPanel } from "@/components/ls/panels/opportunity-search";

export const Route = createFileRoute("/professionals")({
  head: () => ({
    meta: [
      { title: "Professionals — search companies, firms & jobs | LedgerKnect" },
      {
        name: "description",
        content:
          "CAs, accountants and finance freelancers search employers, CA firms and outsourcing partners across Delhi NCR with keyword and parameter matching.",
      },
      {
        property: "og:title",
        content: "Professionals — search companies, firms & jobs | LedgerKnect",
      },
      {
        property: "og:description",
        content:
          "Search hiring companies, CA firms and open assignments ranked by how well they match your keywords and filters.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: ProfessionalsPage,
});

function ProfessionalsPage() {
  return (
    <div className="min-h-screen">
      <SiteHeader />
      <main className="mx-auto w-full max-w-6xl px-5 py-12">
        <p className="text-[11px] font-semibold uppercase tracking-[0.2em] text-muted-foreground">
          Professionals & freelancers
        </p>
        <h1 className="mt-3 text-4xl">Find the right company or assignment</h1>
        <p className="mt-4 max-w-2xl text-sm text-muted-foreground">
          Search hiring companies, CA firms and outsourcing partners by keyword and
          filters. Every result is scored on how closely it matches what you asked for.
        </p>

        <div className="mt-10">
          <OpportunitySearchPanel />
        </div>
      </main>
    </div>
  );
}
