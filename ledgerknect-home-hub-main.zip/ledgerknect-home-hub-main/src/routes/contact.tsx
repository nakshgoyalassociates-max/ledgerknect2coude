import { useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { toast } from "sonner";
import { SiteHeader } from "@/components/ls/site-header";
import { TextAreaField, TextField } from "@/components/ls/fields";

export const Route = createFileRoute("/contact")({
  head: () => ({
    meta: [
      { title: "Contact LedgerKnect — talk to our team" },
      {
        name: "description",
        content:
          "Questions about hiring finance talent, posting an assignment or your professional profile? Send the LedgerKnect team a message.",
      },
      { property: "og:title", content: "Contact LedgerKnect" },
      {
        property: "og:description",
        content: "Reach the LedgerKnect team about hiring, assignments or your profile.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: ContactPage,
});

function ContactPage() {
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [subject, setSubject] = useState("");
  const [message, setMessage] = useState("");

  const submit = () => {
    if (!name.trim() || !email.trim() || !message.trim()) {
      toast.error("Name, email and message are required.");
      return;
    }
    setName("");
    setEmail("");
    setSubject("");
    setMessage("");
    toast.success("Thanks — your message has been noted. We'll get back to you.");
  };

  return (
    <div className="min-h-screen">
      <SiteHeader />
      <main className="mx-auto grid w-full max-w-5xl gap-12 px-5 py-16 lg:grid-cols-[1fr_1.1fr]">
        <div>
          <p className="text-[11px] font-semibold uppercase tracking-[0.2em] text-muted-foreground">
            Contact
          </p>
          <h1 className="mt-3 text-4xl">Talk to the team</h1>
          <p className="mt-5 text-sm text-muted-foreground">
            Hiring, assignments, manpower supply or a question about your profile — send us
            a note and we'll come back to you.
          </p>
          <dl className="mt-8 space-y-4 text-sm">
            <div>
              <dt className="text-muted-foreground">Email</dt>
              <dd>hello@ledgerknect.com</dd>
            </div>
            <div>
              <dt className="text-muted-foreground">Coverage</dt>
              <dd>Delhi, Noida, Greater Noida, Ghaziabad, Gurugram, Faridabad</dd>
            </div>
          </dl>
          <p className="mt-6 text-xs text-muted-foreground">
            These contact details are placeholders — send us the real email and phone number
            and we'll put them in.
          </p>
        </div>

        <section className="space-y-6 rounded-xl border border-border bg-surface p-6">
          <div className="grid gap-5 sm:grid-cols-2">
            <TextField label="Your name" required value={name} onChange={setName} />
            <TextField
              label="Email"
              required
              value={email}
              onChange={setEmail}
              placeholder="you@company.com"
            />
          </div>
          <TextField
            label="Subject"
            value={subject}
            onChange={setSubject}
            placeholder="e.g. Need an audit team for 3 months"
          />
          <TextAreaField
            label="Message"
            value={message}
            maxLength={1200}
            onChange={setMessage}
            placeholder="Tell us what you need…"
          />
          <button
            type="button"
            onClick={submit}
            className="rounded-md bg-primary px-5 py-2.5 text-sm font-medium text-primary-foreground hover:opacity-90"
          >
            Send message
          </button>
        </section>
      </main>
    </div>
  );
}
