import { createFileRoute, Link } from "@tanstack/react-router";
import { SiteHeader } from "@/components/ls/site-header";
import { BoardPanel } from "@/components/ls/panels/board";
import { DEFAULT_WEIGHTS, WEIGHT_LABELS, type Weights } from "@/lib/ledgerskill/data";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "LedgerKnect — Finance Talent & Assignment Matching, Delhi NCR" },
      {
        name: "description",
        content:
          "Skill-first matching between CAs, accountants and finance consultants and the employers, businesses and CA firms who need them across Delhi NCR.",
      },
      {
        property: "og:title",
        content: "LedgerKnect — Finance Talent & Assignment Matching",
      },
      {
        property: "og:description",
        content:
          "A weighted matching engine built around four questions: can they do the work, have they done it before, are they the right level, and are they within budget?",
      },
    ],
  }),
  component: Index,
});

const questions = [
  {
    n: "01",
    q: "Can they do the work?",
    a: "Primary skills, scored against the master finance skill library.",
  },
  {
    n: "02",
    q: "Have they done it before?",
    a: "Primary relevant experience, measured area by area with years.",
  },
  {
    n: "03",
    q: "Are they at the right level?",
    a: "Senior, mid-level or executive — matched against the requirement.",
  },
  {
    n: "04",
    q: "Are they within the expected compensation?",
    a: "Salary band and budget compared before anyone wastes an interview.",
  },
];

const cities = [
  "Delhi",
  "Noida",
  "Greater Noida",
  "Ghaziabad",
  "Gurugram",
  "Faridabad",
];

const audiences = [
  {
    t: "CA firms & finance practitioners",
    d: "Need extra hands on audit, GST or closing work? Post an assignment and get scored professionals you can deploy to your own clients.",
  },
  {
    t: "Back office & outsourcing companies",
    d: "Supply finance manpower to large organisations — request one professional or a whole off-site team by scope and level.",
  },
  {
    t: "Companies with project work",
    d: "Post a specific project — statutory audit, books clean-up, accounting-to-audit handover, MIS or virtual CFO — for a defined duration.",
  },
];

function Index() {
  const keys = Object.keys(DEFAULT_WEIGHTS) as (keyof Weights)[];
  return (
    <div className="min-h-screen">
      <SiteHeader />

      <section className="border-b border-border">
        <div className="mx-auto grid w-full max-w-6xl gap-12 px-5 py-20 lg:grid-cols-[1.15fr_1fr] lg:py-28">
          <div>
            <p className="text-[11px] font-semibold uppercase tracking-[0.22em] text-muted-foreground">
              V1 · Delhi NCR
            </p>
            <h1 className="mt-5 text-5xl leading-[1.05] lg:text-6xl">
              Finance talent, matched on{" "}
              <em className="text-gold">skill and evidence</em> — not keywords.
            </h1>
            <p className="mt-6 max-w-xl text-base text-muted-foreground">
              LedgerKnect scores every finance professional against a requirement using a
              weighted model built for accounting, tax, audit and CFO work — for permanent
              roles, contracts, projects and fractional assignments alike.
            </p>
            <div className="mt-9 flex flex-wrap gap-3">
              <Link
                to="/register" search={{ tab: "professional" as const }}
                className="rounded-md bg-primary px-6 py-3 text-sm font-medium text-primary-foreground transition-opacity hover:opacity-90"
              >
                I'm a finance professional
              </Link>
              <Link
                to="/register" search={{ tab: "employer" as const }}
                className="rounded-md border border-primary px-6 py-3 text-sm font-medium transition-colors hover:bg-accent/50"
              >
                I'm hiring or need an assignment done
              </Link>
            </div>
            <p className="mt-6 text-xs text-muted-foreground">
              Guided questionnaire · roughly 5–10 minutes · nothing shown all at once
            </p>
          </div>

          <div className="rounded-xl border border-border bg-surface p-7">
            <p className="text-[11px] font-semibold uppercase tracking-[0.16em] text-muted-foreground">
              The matching model
            </p>
            <ul className="mt-5 space-y-3">
              {keys.map((k) => (
                <li key={k}>
                  <div className="flex items-baseline justify-between text-sm">
                    <span>{WEIGHT_LABELS[k]}</span>
                    <span className="tabular-nums text-muted-foreground">
                      {DEFAULT_WEIGHTS[k]}%
                    </span>
                  </div>
                  <div className="mt-1.5 h-1.5 rounded-full bg-muted">
                    <div
                      className="h-full rounded-full bg-gold"
                      style={{ width: `${(DEFAULT_WEIGHTS[k] / 30) * 100}%` }}
                    />
                  </div>
                </li>
              ))}
            </ul>
            <p className="mt-5 text-xs text-muted-foreground">
              Weights are configurable from the admin panel. Mandatory requirements are
              checked for eligibility before any score is calculated.
            </p>
          </div>
        </div>
      </section>

      <section className="border-b border-border">
        <div className="mx-auto w-full max-w-6xl px-5 py-20">
          <h2 className="max-w-2xl text-3xl lg:text-4xl">
            Hiring, assignments and manpower supply — in one place.
          </h2>
          <div className="mt-10 grid gap-px overflow-hidden rounded-xl border border-border bg-border sm:grid-cols-3">
            {audiences.map((a) => (
              <div key={a.t} className="bg-surface p-7">
                <h3 className="text-lg">{a.t}</h3>
                <p className="mt-2 text-sm text-muted-foreground">{a.d}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="border-b border-border bg-surface/60">
        <div className="mx-auto w-full max-w-6xl px-5 py-20">
          <p className="text-[11px] font-semibold uppercase tracking-[0.2em] text-muted-foreground">
            Open board
          </p>
          <div className="mt-4">
            <BoardPanel
              allowPost
              heading="Live vacancies & assignments"
              blurb="Post an ad here — employers, CA firms and professionals all advertise on this one board. Contact details unlock with credits."
            />
          </div>
        </div>
      </section>

      <section className="border-b border-border">
        <div className="mx-auto w-full max-w-6xl px-5 py-20">
          <h2 className="max-w-2xl text-3xl lg:text-4xl">
            Four questions decide every match.
          </h2>
          <div className="mt-10 grid gap-px overflow-hidden rounded-xl border border-border bg-border sm:grid-cols-2">
            {questions.map((q) => (
              <div key={q.n} className="bg-surface p-7">
                <span className="font-display text-3xl text-gold">{q.n}</span>
                <h3 className="mt-3 text-xl">{q.q}</h3>
                <p className="mt-2 text-sm text-muted-foreground">{q.a}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section>
        <div className="mx-auto grid w-full max-w-6xl gap-10 px-5 py-20 lg:grid-cols-2">
          <div>
            <h2 className="text-3xl lg:text-4xl">Built for Delhi NCR first.</h2>
            <p className="mt-4 text-sm text-muted-foreground">
              V1 covers the NCR finance market end to end. The data model is city-agnostic,
              so new locations can be added later without touching the matching engine.
            </p>
            <div className="mt-6 flex flex-wrap gap-2">
              {cities.map((c) => (
                <span
                  key={c}
                  className="rounded-full border border-border bg-card px-3.5 py-1.5 text-[13px]"
                >
                  {c}
                </span>
              ))}
            </div>
          </div>
          <div className="rounded-xl border border-border bg-surface p-7">
            <h3 className="text-xl">Match categories</h3>
            <ul className="mt-4 space-y-2 text-sm">
              {[
                ["90–100%", "Excellent Match"],
                ["80–89%", "Strong Match"],
                ["70–79%", "Good Match"],
                ["60–69%", "Potential Match"],
                ["Below 60%", "Low Match"],
              ].map(([range, label]) => (
                <li
                  key={range}
                  className="flex justify-between border-b border-border pb-2 last:border-0"
                >
                  <span className="text-muted-foreground">{range}</span>
                  <span className="font-medium">{label}</span>
                </li>
              ))}
            </ul>
            <Link
              to="/recruiters" search={{ tab: "talent" as const }}
              className="mt-6 inline-flex rounded-md border border-border px-4 py-2 text-sm hover:bg-accent/50"
            >
              See a live match result
            </Link>
          </div>
        </div>
      </section>

      <footer className="border-t border-border">
        <div className="mx-auto flex w-full max-w-6xl flex-wrap items-center justify-between gap-3 px-5 py-8 text-xs text-muted-foreground">
          <span>LedgerKnect · Finance Talent & Assignment Matching · V1 Delhi NCR</span>
          <span>Matching weights configurable from the admin panel</span>
        </div>
      </footer>
    </div>
  );
}
