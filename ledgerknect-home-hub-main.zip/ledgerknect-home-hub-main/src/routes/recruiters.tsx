import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { SiteHeader } from "@/components/ls/site-header";
import { TalentSearchPanel } from "@/components/ls/panels/talent-search";
import { MatchesPanel } from "@/components/ls/panels/matches";
import { ClientForm } from "@/components/ls/panels/client-form";
import { cn } from "@/lib/utils";

type Tab = "talent" | "post";

export const Route = createFileRoute("/recruiters")({
  validateSearch: (
    search: Record<string, unknown>,
  ): { tab?: Tab | undefined; req?: string | undefined } => {
    const tab = search["tab"];
    const req = search["req"];
    return {
      ...(tab === "talent" || tab === "post" ? { tab } : {}),
      ...(typeof req === "string" ? { req } : {}),
    };
  },
  head: () => ({
    meta: [
      { title: "Recruiters & employers — find finance talent | LedgerKnect" },
      {
        name: "description",
        content:
          "Search CAs and finance professionals across Delhi NCR, review weighted match results, post a hiring or assignment requirement and manage your recruiter ads.",
      },
      {
        property: "og:title",
        content: "Recruiters & employers — find finance talent | LedgerKnect",
      },
      {
        property: "og:description",
        content:
          "Candidate search, match results and requirement posting in one workspace.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: RecruitersPage,
});

const tabs: { id: Tab; label: string }[] = [
  { id: "talent", label: "Find talent & matches" },
  { id: "post", label: "Post a requirement" },
];

function RecruitersPage() {
  const { tab, req } = Route.useSearch();
  const navigate = useNavigate();
  const active: Tab = tab ?? "talent";

  return (
    <div className="min-h-screen">
      <SiteHeader />
      <main className="mx-auto w-full max-w-6xl px-5 py-12">
        <p className="text-[11px] font-semibold uppercase tracking-[0.2em] text-muted-foreground">
          Recruiters & employers
        </p>
        <h1 className="mt-3 text-4xl">Hire finance talent</h1>

        <div className="mt-6 flex flex-wrap gap-2 border-b border-border pb-3">
          {tabs.map((t) => (
            <button
              key={t.id}
              type="button"
              onClick={() =>
                void navigate({ to: "/recruiters", search: { tab: t.id }, replace: true })
              }
              className={cn(
                "rounded-full border px-4 py-1.5 text-[13px] transition-colors",
                t.id === active
                  ? "border-primary bg-primary text-primary-foreground"
                  : "border-border bg-card hover:bg-accent/40",
              )}
            >
              {t.label}
            </button>
          ))}
        </div>

        <div className="mt-8">
          {active === "talent" && (
            <div className="space-y-14">
              <TalentSearchPanel />
              <MatchesPanel req={req} />
            </div>
          )}
          {active === "post" && <ClientForm />}
        </div>
      </main>
    </div>
  );
}
