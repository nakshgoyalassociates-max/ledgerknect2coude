import { createFileRoute, redirect } from "@tanstack/react-router";

export const Route = createFileRoute("/hire")({
  beforeLoad: () => {
    throw redirect({ to: "/recruiters", search: { tab: "talent" as const } });
  },
});
