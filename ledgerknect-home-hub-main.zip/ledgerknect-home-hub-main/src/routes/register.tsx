import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { SiteHeader } from "@/components/ls/site-header";
import { CandidateForm } from "@/components/ls/panels/candidate-form";
import { ClientForm } from "@/components/ls/panels/client-form";
import { cn } from "@/lib/utils";

type Tab = "professional" | "employer";

export const Route = createFileRoute("/register")({
  validateSearch: (search: Record<string, unknown>): { tab?: Tab | undefined } => {
    const tab = search["tab"];
    return tab === "professional" || tab === "employer" ? { tab } : {};
  },
  head: () => ({
    meta: [
      { title: "Register — professionals & employers | LedgerKnect" },
      {
        name: "description",
        content:
          "Create a finance professional profile or register as an employer, CA firm or business and post what you need — one guided questionnaire for both.",
      },
      { property: "og:title", content: "Register — professionals & employers | LedgerKnect" },
      {
        property: "og:description",
        content:
          "A short guided questionnaire for CAs, accountants, employers and CA firms across Delhi NCR.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: RegisterPage,
});

const tabs: { id: Tab; label: string }[] = [
  { id: "professional", label: "I am a professional" },
  { id: "employer", label: "I am an employer / firm" },
];

function RegisterPage() {
  const { tab } = Route.useSearch();
  const navigate = useNavigate();
  const active: Tab = tab ?? "professional";

  return (
    <div className="min-h-screen">
      <SiteHeader />
      <main className="mx-auto w-full max-w-6xl px-5 pt-12">
        <p className="text-[11px] font-semibold uppercase tracking-[0.2em] text-muted-foreground">
          Registration
        </p>
        <h1 className="mt-3 text-4xl">Join LedgerKnect</h1>
        <div className="mt-6 flex flex-wrap gap-2 border-b border-border pb-3">
          {tabs.map((t) => (
            <button
              key={t.id}
              type="button"
              onClick={() =>
                void navigate({ to: "/register", search: { tab: t.id }, replace: true })
              }
              className={cn(
                "rounded-full border px-4 py-1.5 text-[13px] transition-colors",
                t.id === active
                  ? "border-primary bg-primary text-primary-foreground"
                  : "border-border bg-card hover:bg-accent/40",
              )}
            >
              {t.label}
            </button>
          ))}
        </div>
      </main>
      {active === "professional" ? <CandidateForm /> : <ClientForm />}
    </div>
  );
}
