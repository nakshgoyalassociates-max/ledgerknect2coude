import { createFileRoute, Link } from "@tanstack/react-router";
import { SiteHeader } from "@/components/ls/site-header";

export const Route = createFileRoute("/about")({
  head: () => ({
    meta: [
      { title: "About LedgerKnect — skill-first finance talent matching" },
      {
        name: "description",
        content:
          "LedgerKnect connects CAs, accountants and finance consultants with employers, businesses and CA firms across Delhi NCR using a weighted, evidence-based matching model.",
      },
      { property: "og:title", content: "About LedgerKnect" },
      {
        property: "og:description",
        content:
          "Why we built a skill-first matching engine for accounting, tax, audit and CFO work.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: AboutPage,
});

const values = [
  {
    t: "Evidence over keywords",
    d: "Every professional is scored on demonstrated skills and relevant experience, not on how well a CV is worded.",
  },
  {
    t: "One board for everyone",
    d: "Employers, CA firms, outsourcing partners and professionals all advertise on the same open board.",
  },
  {
    t: "Built for finance work",
    d: "Statutory audit, GST, closing, MIS, virtual CFO and project assignments — the model is designed around how finance work is actually scoped.",
  },
  {
    t: "Delhi NCR first",
    d: "V1 covers the NCR market end to end, with a data model ready for more cities.",
  },
];

function AboutPage() {
  return (
    <div className="min-h-screen">
      <SiteHeader />
      <main className="mx-auto w-full max-w-4xl px-5 py-16">
        <p className="text-[11px] font-semibold uppercase tracking-[0.2em] text-muted-foreground">
          About us
        </p>
        <h1 className="mt-3 text-4xl lg:text-5xl">
          Finance talent, matched on <em className="text-gold">skill and evidence</em>.
        </h1>
        <p className="mt-6 text-base text-muted-foreground">
          LedgerKnect is a matching platform for the finance profession. Professionals
          describe what they can do and what they have done; employers, businesses and CA
          firms describe the work that needs doing. A weighted model compares the two and
          gives both sides a score they can act on — for permanent roles, contracts,
          projects and fractional assignments alike.
        </p>

        <div className="mt-12 grid gap-px overflow-hidden rounded-xl border border-border bg-border sm:grid-cols-2">
          {values.map((v) => (
            <div key={v.t} className="bg-surface p-7">
              <h2 className="text-lg">{v.t}</h2>
              <p className="mt-2 text-sm text-muted-foreground">{v.d}</p>
            </div>
          ))}
        </div>

        <div className="mt-12 flex flex-wrap gap-3">
          <Link
            to="/register"
            search={{ tab: "professional" as const }}
            className="rounded-md bg-primary px-6 py-3 text-sm font-medium text-primary-foreground hover:opacity-90"
          >
            Register as a professional
          </Link>
          <Link
            to="/contact"
            className="rounded-md border border-primary px-6 py-3 text-sm font-medium hover:bg-accent/50"
          >
            Talk to us
          </Link>
        </div>
      </main>
    </div>
  );
}
