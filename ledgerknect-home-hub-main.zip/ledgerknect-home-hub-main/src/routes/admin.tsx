import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { toast } from "sonner";
import { SiteHeader } from "@/components/ls/site-header";
import { DEFAULT_WEIGHTS, WEIGHT_LABELS, type Weights } from "@/lib/ledgerskill/data";
import { getCandidates, getRequirements, getWeights, saveWeights } from "@/lib/ledgerskill/store";
import {
  DEFAULT_CREDITS,
  VIEWER,
  addCredits,
  getBalance,
} from "@/lib/ledgerskill/credits";

export const Route = createFileRoute("/admin")({
  head: () => ({
    meta: [
      { title: "Admin panel | LedgerKnect" },
      {
        name: "description",
        content:
          "Configure LedgerKnect matching weights and review registered professionals and posted requirements.",
      },
      { property: "og:title", content: "Admin panel | LedgerKnect" },
      {
        property: "og:description",
        content: "Tune the weighted matching model behind LedgerKnect.",
      },
    ],
  }),
  component: AdminPage,
});

function AdminPage() {
  const [weights, setWeights] = useState<Weights>(DEFAULT_WEIGHTS);
  const [counts, setCounts] = useState({ candidates: 0, requirements: 0 });
  const [accounts, setAccounts] = useState<
    { id: string; label: string; kind: string; balance: number }[]
  >([]);
  const [topUp, setTopUp] = useState(10);

  const refreshAccounts = () => {
    const cands = getCandidates().map((c) => ({
      id: c.id,
      label: c.fullName || "Unnamed professional",
      kind: "Professional",
      balance: getBalance(c.id),
    }));
    const reqs = getRequirements().map((r) => ({
      id: r.id,
      label: r.companyName || "Untitled requirement",
      kind: "Client",
      balance: getBalance(r.id),
    }));
    setAccounts([
      { id: VIEWER, label: "This browser (demo wallet)", kind: "Viewer", balance: getBalance(VIEWER) },
      ...cands,
      ...reqs,
    ]);
  };

  useEffect(() => {
    setWeights(getWeights());
    setCounts({
      candidates: getCandidates().length,
      requirements: getRequirements().length,
    });
    refreshAccounts();
  }, []);

  const keys = Object.keys(weights) as (keyof Weights)[];
  const total = keys.reduce((a, k) => a + weights[k], 0);

  return (
    <div className="min-h-screen">
      <SiteHeader />
      <main className="mx-auto w-full max-w-4xl px-5 py-12">
        <p className="text-[11px] font-semibold uppercase tracking-[0.2em] text-muted-foreground">
          Admin panel
        </p>
        <h1 className="mt-3 text-4xl">Matching weights</h1>
        <p className="mt-2 text-sm text-muted-foreground">
          {counts.candidates} professionals · {counts.requirements} requirements. Weights
          are applied instantly to every match calculation.
        </p>

        <div className="mt-8 space-y-5 rounded-xl border border-border bg-surface p-6">
          {keys.map((k) => (
            <div key={k} className="flex items-center gap-4">
              <span className="w-56 shrink-0 text-sm font-medium">{WEIGHT_LABELS[k]}</span>
              <input
                type="range"
                min={0}
                max={50}
                value={weights[k]}
                onChange={(e) =>
                  setWeights({ ...weights, [k]: Number(e.target.value) })
                }
                className="flex-1 accent-[var(--primary)]"
              />
              <span className="w-12 text-right text-sm tabular-nums">{weights[k]}%</span>
            </div>
          ))}
          <div className="flex items-center justify-between border-t border-border pt-4">
            <span className="text-sm font-semibold">
              Total {total}%{" "}
              {total !== 100 && (
                <span className="text-warning">(scores are normalised)</span>
              )}
            </span>
            <div className="flex gap-2">
              <button
                type="button"
                onClick={() => setWeights(DEFAULT_WEIGHTS)}
                className="rounded-md border border-border px-4 py-2 text-sm hover:bg-accent/50"
              >
                Reset
              </button>
              <button
                type="button"
                onClick={() => {
                  saveWeights(weights);
                  toast.success("Matching weights updated.");
                }}
                className="rounded-md bg-primary px-5 py-2 text-sm font-medium text-primary-foreground hover:opacity-90"
              >
                Save weights
              </button>
            </div>
          </div>
        </div>

        <section className="mt-10 rounded-xl border border-border bg-surface p-6">
          <h2 className="text-2xl">Credits</h2>
          <p className="mt-2 text-sm text-muted-foreground">
            Contact details cost 1 credit to unlock. Every account starts with{" "}
            {DEFAULT_CREDITS} credits for testing — top up any account below.
          </p>

          <div className="mt-5 flex items-center gap-3">
            <label className="text-sm text-muted-foreground" htmlFor="topup">
              Credits to add
            </label>
            <input
              id="topup"
              type="number"
              min={1}
              value={topUp}
              onChange={(e) => setTopUp(Math.max(1, Number(e.target.value) || 1))}
              className="w-24 rounded-md border border-border bg-card px-3 py-1.5 text-sm"
            />
          </div>

          <div className="mt-4 divide-y divide-border">
            {accounts.map((a) => (
              <div key={`${a.kind}-${a.id}`} className="flex items-center gap-4 py-3">
                <span className="w-24 shrink-0 text-[11px] font-semibold uppercase tracking-[0.14em] text-muted-foreground">
                  {a.kind}
                </span>
                <span className="flex-1 text-sm">{a.label}</span>
                <span className="w-24 text-right text-sm tabular-nums">
                  {a.balance} credits
                </span>
                <button
                  type="button"
                  onClick={() => {
                    addCredits(a.id, topUp);
                    refreshAccounts();
                    toast.success(`Added ${topUp} credits to ${a.label}.`);
                  }}
                  className="rounded-md border border-border px-3 py-1.5 text-sm hover:bg-accent/50"
                >
                  Add credits
                </button>
              </div>
            ))}
          </div>
        </section>
      </main>
    </div>
  );
}