import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { SiteHeader } from "@/components/ls/site-header";
import { ContactReveal } from "@/components/ls/contact-reveal";
import { getRequirements } from "@/lib/ledgerskill/store";
import type { ClientRequirement } from "@/lib/ledgerskill/types";

export const Route = createFileRoute("/requirement/$id")({
  head: () => ({
    meta: [
      { title: "Requirement details | LedgerKnect" },
      {
        name: "description",
        content:
          "Full client requirement details: assignment scope, mandatory and preferred criteria, budget, locations and engagement terms.",
      },
      { property: "og:title", content: "Requirement details | LedgerKnect" },
      {
        property: "og:description",
        content: "Drill down into a client's complete finance manpower requirement.",
      },
    ],
  }),
  component: RequirementPage,
});

function RequirementPage() {
  const { id } = Route.useParams();
  const [ready, setReady] = useState(false);
  const [req, setReq] = useState<ClientRequirement | null>(null);

  useEffect(() => {
    setReq(getRequirements().find((r) => r.id === id) ?? null);
    setReady(true);
  }, [id]);

  return (
    <div className="min-h-screen">
      <SiteHeader />
      <main className="mx-auto w-full max-w-5xl px-5 py-12">
        <Link to="/recruiters" search={{ tab: "talent" as const }} className="text-sm underline underline-offset-4">
          ← Back to find talent
        </Link>
        {!ready ? (
          <p className="mt-10 text-sm text-muted-foreground">Loading requirement…</p>
        ) : !req ? (
          <p className="mt-10 text-sm text-muted-foreground">Requirement not found.</p>
        ) : (
          <>
            <h1 className="mt-6 text-4xl">{req.companyName || "Untitled requirement"}</h1>
            <p className="mt-2 text-sm text-muted-foreground">
              {[req.assignmentTitle, req.requirementType, req.managementLevel]
                .filter(Boolean)
                .join(" · ")}
            </p>
            {req.description && <p className="mt-4 max-w-3xl text-sm">{req.description}</p>}

            <Section title="Company">
              <Row label="Client type" value={req.userType} />
              <RowNode label="Contact person">
                <ContactReveal
                  contactId={`requirement:${req.id}:person`}
                  value={req.contactPerson}
                />
              </RowNode>
              <RowNode label="Email">
                <ContactReveal
                  contactId={`requirement:${req.id}:email`}
                  value={req.email}
                  kind="email"
                />
              </RowNode>
              <RowNode label="Mobile">
                <ContactReveal
                  contactId={`requirement:${req.id}:mobile`}
                  value={req.mobile}
                  kind="phone"
                />
              </RowNode>
              <Row label="Location" value={req.companyLocation} />
              <Row label="Industry" value={req.industry} />
              <Row label="Company size" value={req.companySize} />
              <Row label="Turnover" value={req.turnover} />
            </Section>

            <Section title="Assignment">
              <Row label="Requirement type" value={req.requirementType} />
              <Row label="Assignment types" value={req.assignmentTypes.join(", ")} />
              <Row label="Headcount" value={req.headcount} />
              <Row label="Deployment" value={req.deployment} />
              <Row label="Start date" value={req.startDate} />
              <Row label="Weekly requirement" value={req.weeklyRequirement} />
            </Section>

            <Section title="Skills & experience">
              <Row label="Primary skills" value={req.primarySkills.join(", ")} />
              <Row label="Secondary skills" value={req.secondarySkills.join(", ")} />
              <Row
                label="Primary experience"
                value={req.primaryExperience.map((e) => `${e.name} (${e.years})`).join(", ")}
              />
              <Row
                label="Secondary experience"
                value={req.secondaryExperience.map((e) => `${e.name} (${e.years})`).join(", ")}
              />
            </Section>

            <Section title="Qualifications, software & industry">
              <Row label="Mandatory qualifications" value={req.mandatoryQualifications.join(", ")} />
              <Row label="Preferred qualifications" value={req.preferredQualifications.join(", ")} />
              <Row label="Mandatory software" value={req.mandatorySoftware.join(", ")} />
              <Row label="Preferred software" value={req.preferredSoftware.join(", ")} />
              <Row label="Primary industry" value={req.primaryIndustry} />
              <Row label="Preferred industries" value={req.preferredIndustries.join(", ")} />
            </Section>

            <Section title="Engagement & budget">
              <Row label="Work mode" value={req.workMode} />
              <Row label="Locations" value={req.locations.join(", ")} />
              <Row label="Engagement types" value={req.engagementTypes.join(", ")} />
              <Row label="Durations" value={req.durations.join(", ")} />
              <Row label="Salary band" value={req.salaryBand} />
              <Row label="Max salary" value={req.maxSalary} />
              <Row label="Billing method" value={req.billingMethod} />
              <Row label="Budget" value={req.budget} />
            </Section>

            <Section title="Priorities">
              {Object.entries(req.priorities).map(([k, v]) => (
                <Row key={k} label={k} value={v} />
              ))}
            </Section>
          </>
        )}
      </main>
    </div>
  );
}

function Section({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <section className="mt-8 rounded-xl border border-border bg-surface p-6">
      <h2 className="text-xl">{title}</h2>
      <dl className="mt-4 grid gap-4 text-sm sm:grid-cols-2">{children}</dl>
    </section>
  );
}

function Row({ label, value }: { label: string; value: string }) {
  return (
    <div>
      <dt className="text-[11px] font-semibold uppercase tracking-[0.14em] text-muted-foreground">
        {label}
      </dt>
      <dd className="mt-1">{value || "—"}</dd>
    </div>
  );
}

function RowNode({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div>
      <dt className="text-[11px] font-semibold uppercase tracking-[0.14em] text-muted-foreground">
        {label}
      </dt>
      <dd className="mt-1">{children}</dd>
    </div>
  );
}
